// Real current ProviderRegistry / local HTTP adapters, one real Qwen3-4B server.
// An observer replaces A9 for this isolated probe; it grants no production authority.
import { createProviderRegistryFromEnv, withProviderWorkContext } from '../YUVI-multi-character/packages/providers/dist/index.js';
import { writeFileSync } from 'node:fs';
const accounting:any[]=[];
const port=(label:string)=>({async invoke(task:any,leaf:any,call:any,signal:any){accounting.push({port:label,scope:task.context?.scope,configuration:task.configurationRef,operation:task.operation,leaf});return call(signal);},async *stream(task:any,leaf:any,call:any,signal:any){yield*call(signal);}});
function registry(label:string){const r=createProviderRegistryFromEnv({NODE_ENV:'production',PROVIDER_ALLOW_MOCKS:'false',DEFAULT_CHAT_PROVIDER:'local',CHAT_PROVIDER_CHAIN:'local',LOCAL_MODEL_BASEURL:'http://127.0.0.1:8101/v1',LOCAL_CHAT_MODEL:'qwen3-4b-research'});r.setAccounting(port(label));return r;}
const a=registry('A'),b=registry('B'),results:any[]=[];
async function call(r:any,scope:string,identity:string,user:string){const input={messages:[{role:'system',content:`你的名字是${identity}。按要求回答，最多十个汉字。/no_think`},{role:'user',content:user}],temperature:0,maxTokens:32};const start=performance.now();const output=await withProviderWorkContext({scope},()=>r.getChatProvider().generateReply(input));const row={scope,input,output,wallMs:performance.now()-start};results.push(row);return row;}
await Promise.all([call(a,'character:A','Yuvi','只说你的名字。'),call(b,'character:B','东方爱丽丝','只说你的名字。')]);
await call(a,'character:A','Yuvi','这段独立上下文的暗号是 A-ONLY-7319。只返回暗号。');
await call(b,'character:B','东方爱丽丝','当前对话没有提供任何暗号。如果不知道暗号，只回答“不知道”。');
// This deliberately reuses A's mutable registry with B's accounting port.
a.setAccounting(port('B'));await call(a,'character:A','Yuvi','只说你的名字。');
const result={engine:'llama.cpp b11457',model:'Qwen3-4B Q4_K_M',singleEndpoint:'http://127.0.0.1:8101/v1',singleModelProcess:true,slots:1,accounting,results,limitation:'Transport/model-serving and mutable accounting reproduction, not a durable multi-Character production acceptance test.'};
writeFileSync('/workspace/research/multi-character/shared-provider-result.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({accounting,answers:results.map(x=>({scope:x.scope,text:x.output.message.content,wallMs:x.wallMs}))},null,2));
