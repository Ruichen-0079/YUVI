import { randomUUID } from "node:crypto";
import {
  appendFileSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";
import type { AgentState } from "@letta-ai/letta-client/resources/agents/agents";
import type { LettaStreamingResponse } from "@letta-ai/letta-client/resources/agents/messages";
import type { Conversation } from "@letta-ai/letta-client/resources/conversations/conversations";
import type {
  AgentCreateBody,
  AgentListBody,
  AgentMessageListBody,
  AgentUpdateBody,
  ConversationCreateBody,
  ConversationListBody,
  ConversationMessageCreateBody,
  ConversationMessageListBody,
  ConversationMessageStreamBody,
  ConversationUpdateBody,
} from "@/backend/backend";
import { INTERRUPTED_BY_USER } from "@/constants";
import { isRecord } from "@/utils/type-guards";
import type { LocalCompactionStats } from "./compaction";
import {
  createDefaultAgentRecord,
  createLocalAgentRecord,
  isHiddenLocalAgentRecord,
  normalizeAgentRecord,
  projectLocalAgentState,
  shouldPersistSubagentHiddenBackfill,
  shouldUseDefaultLocalModel,
} from "./local-agent-record";
import { selectLocalMessagesForFork } from "./local-conversation-fork";
import { listLocalConversations } from "./local-conversation-list";
import {
  agentFreeExecutionRecord,
  createLocalConversationRecord,
  isStringArray,
  parsePersistedLocalConversation,
  updateLocalConversationRecord,
} from "./local-conversation-record";
import {
  emptyLocalUsage,
  type LocalAssistantMessage,
  type LocalImageContent,
  type LocalMessage,
  type LocalTextContent,
  type LocalToolCall,
  type LocalToolResultMessage,
  type LocalUserMessage,
  localToolArgumentsFromUnknown,
} from "./local-message";
import {
  clipOversizedLocalToolResults,
  cloneLocalMessage,
  isLocalToolCallContent,
  mergeSnapshotContentWithExistingToolCalls,
  projectedMessageLookupKeys,
  projectLocalMessageToStoredMessages,
  removeOrphanLocalToolResults,
  sourceLocalMessageIdFromStoredMessageId,
  withProjectedMessageDates,
} from "./local-message-projection";
import {
  normalizeLocalModelHandle,
  normalizeStoredLocalModelRecord,
  supportedModelSettingsFromBody,
} from "./local-model-normalization";
import {
  canonicalizeLocalStreamChunk,
  getAttachedLocalMessage,
  isLocalStateChunkOnly,
  toStoredOutputFields,
} from "./local-stream-chunks";
import {
  assertNoLegacyUiMessageRows,
  createLocalTranscriptManifest,
  createLocalTranscriptSessionHeader,
  hasNonEmptyJsonl,
  isSyntheticLocalTimestamp,
  jsonl,
  LOCAL_TRANSCRIPT_LEGACY_MESSAGE_FORMAT,
  LOCAL_TRANSCRIPT_MESSAGE_FORMAT,
  type LocalTranscriptAppendEntry,
  type LocalTranscriptCompactionEntry,
  type LocalTranscriptMessageFormat,
  type LocalTranscriptRowsResult,
  type LocalTranscriptSessionEntry,
  type LocalTranscriptSessionMessageEntry,
  type LocalTranscriptTiming,
  localMessageDate,
  localMessagesHaveSameSnapshot,
  localTranscriptRowsResult,
  localTranscriptSessionEntries,
  localTranscriptTailMessages,
  messagesMissingFrom,
  normalizeLocalMessageForPi,
  overlayResidentLocalMessageSuffix,
  overlayResidentLocalMessageTail,
  readJsonFile,
  readJsonlFile,
  readJsonlFileSuffix,
  readLocalTranscriptTailWindow,
  repairSyntheticConversationTimestamps,
  repairSyntheticLocalMessageTimestamps,
  residentCoversIds,
  restrictLocalTranscriptToResidentMessages,
  spliceOutOfContextMessages,
  timestampFromIso,
  transcriptManifestPath,
  transcriptMessagesPath,
  transcriptTimingForConversationDir,
  validateLocalTranscriptManifest,
  validateUnreadTranscriptHead,
  writeLocalTranscriptManifest,
} from "./local-transcript";
import type {
  LocalAgentRecord,
  StoredConversation,
  StoredMessage,
} from "./local-types";
import type { LocalCompiledSystemPrompt } from "./system-prompt-compilation";
export type { LocalAgentRecord, StoredMessage };

const DEFAULT_LOCAL_AGENT_NAME = "Letta Code";
const DEFAULT_LOCAL_MODEL = "local/default";
const LEGACY_LOCAL_CONTEXT_WINDOW_LIMIT = 128000;
const DEFAULT_LOCAL_CONVERSATION_ID_PREFIX = "local-conv-";
const DEFAULT_LOCAL_STORED_MESSAGE_ID_PREFIX = "letta-msg-";
const DEFAULT_LOCAL_UI_MESSAGE_ID_PREFIX = "ui-msg-";

/**
 * Resident floor per conversation on disk-backed stores: the window always
 * holds every in-context message, and messages that left the context are only
 * evicted beyond this many. Doubles the cloud BACKFILL_PAGE_LIMIT (50).
 */
export const DEFAULT_RESIDENT_MESSAGE_TAIL_LIMIT = 100;

function optionalString(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function currentIsoTimestamp(): string {
  return new Date().toISOString();
}

function textContent(text: string) {
  return [{ type: "text" as const, text }];
}

function normalizeContent(content: unknown): unknown {
  if (typeof content === "string") {
    return textContent(content);
  }
  return content;
}

function localImageContentFromLegacyImage(
  part: Record<string, unknown>,
): LocalImageContent | null {
  if (part.type !== "image" || !isRecord(part.source)) return null;
  const source = part.source;
  if (source.type !== "base64") return null;
  const mediaType = source.media_type;
  const data = source.data;
  if (typeof mediaType !== "string" || typeof data !== "string") return null;
  return { type: "image", mimeType: mediaType, data };
}

function textFromContent(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (!isRecord(part)) return "";
        if (part.type === "text" && typeof part.text === "string") {
          return part.text;
        }
        return "";
      })
      .filter((text) => text.length > 0)
      .join("\n");
  }
  if (content === undefined || content === null) return "";
  return JSON.stringify(content);
}

function parseToolInput(input: unknown): unknown {
  if (typeof input !== "string") return input ?? {};
  try {
    return JSON.parse(input) as unknown;
  } catch {
    return input;
  }
}

function getListLimit(
  body?: ConversationMessageListBody | AgentMessageListBody,
) {
  const limit = (body as { limit?: unknown } | undefined)?.limit;
  return typeof limit === "number" && limit > 0 ? limit : undefined;
}

function getListOrder(
  body?: ConversationMessageListBody | AgentMessageListBody,
) {
  const order = (body as { order?: unknown } | undefined)?.order;
  return order === "asc" ? "asc" : "desc";
}

function getCursor(
  body: ConversationMessageListBody | AgentMessageListBody | undefined,
  key: "before" | "after",
): string | undefined {
  const value = (body as Record<string, unknown> | undefined)?.[key];
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function getIncludedMessageTypes(
  body?: ConversationMessageListBody | AgentMessageListBody,
): Set<string> | undefined {
  const value = (body as Record<string, unknown> | undefined)
    ?.include_return_message_types;
  if (!Array.isArray(value)) return undefined;

  const messageTypes = value.filter(
    (item): item is string => typeof item === "string" && item.length > 0,
  );
  return messageTypes.length > 0 ? new Set(messageTypes) : undefined;
}

export interface StoredTurnInput {
  agentId: string;
  conversationId: string;
}

export interface LocalCompactionStoreResult {
  numMessagesBefore: number;
  numMessagesAfter: number;
  summaryMessage: LocalMessage;
}

export interface LocalStoreOptions {
  storageDir?: string;
  seedDefaultAgent?: boolean;
  strictAgentAccess?: boolean;
  strictConversationAccess?: boolean;
  defaultAgentName?: string;
  defaultAgentModel?: string;
  defaultAgentModelSettings?: Record<string, unknown>;
  modelSettingsForModel?: (
    model: string,
  ) => Record<string, unknown> | undefined;
  conversationIdPrefix?: string;
  storedMessageIdPrefix?: string;
  localMessageIdPrefix?: string;
  /**
   * Resident floor for disk-backed stores; in-memory stores keep the full
   * transcript resident (no disk to page from).
   */
  residentMessageTailLimit?: number;
}

export class LocalBackendNotFoundError extends Error {
  readonly status = 404;

  constructor(resource: string, id: string) {
    super(`${resource} ${id} not found`);
    this.name = "LocalBackendNotFoundError";
  }
}

type LocalContentPart = LocalTextContent | LocalImageContent;
type LocalToolCallContent = LocalToolCall;

function encodePathSegment(value: string): string {
  return Buffer.from(value).toString("base64url");
}

function numericSuffix(value: string, prefix: string): number {
  return value.startsWith(prefix)
    ? Number.parseInt(value.slice(prefix.length), 10) || 0
    : 0;
}

interface LocalConversationTranscriptMetadata {
  conversationDir: string;
  messagesPath: string;
  messageFormat: LocalTranscriptMessageFormat;
  manifestValidated: boolean;
  timing: LocalTranscriptTiming;
  requiresFullTimestampRepair: boolean;
}

interface LocalTranscriptPersistOptions {
  transcript?: "append" | "append-compaction" | "rewrite" | "skip";
  message?: LocalMessage;
  compaction?: {
    summaryMessage: LocalMessage;
    summary: string;
    firstKeptMessageId?: string;
    previousMessages?: readonly LocalMessage[];
    stats?: LocalCompactionStats;
  };
}

function projectLocalMessageAtSourceIndex(
  localMessage: LocalMessage,
  agentId: string,
  conversationId: string,
  sourceIndex: number,
): StoredMessage[] {
  return withProjectedMessageDates(
    projectLocalMessageToStoredMessages(
      localMessage,
      agentId,
      conversationId,
      new Date(Date.UTC(2026, 0, 1, 0, 0, sourceIndex + 1)).toISOString(),
    ),
    sourceIndex,
  );
}

export class LocalStore {
  private readonly storageDir?: string;
  private readonly strictAgentAccess: boolean;
  private readonly strictConversationAccess: boolean;
  private readonly defaultAgentName: string;
  private readonly defaultAgentModel: string;
  private readonly defaultAgentModelSettings: Record<string, unknown>;
  private readonly modelSettingsForModel?: (
    model: string,
  ) => Record<string, unknown> | undefined;
  private readonly conversationIdPrefix: string;
  private readonly storedMessageIdPrefix: string;
  private readonly localMessageIdPrefix: string;
  private readonly agents = new Map<string, LocalAgentRecord>();
  private readonly agentRecordMtimeMsById = new Map<string, number>();
  private readonly conversations = new Map<string, StoredConversation>();
  private readonly localMessagesByConversationKey = new Map<
    string,
    LocalMessage[]
  >();
  // A conversation key is fully resident (loadedConversationKeys) or tail
  // resident (tailResidentConversationKeys — the in-context window, disk wins).
  private readonly loadedConversationKeys = new Set<string>();
  private readonly tailResidentConversationKeys = new Set<string>();
  // First resident message's logical index (sourceStartIndex convention).
  private readonly residentTailStartIndexByConversationKey = new Map<
    string,
    number
  >();
  private readonly residentMessageTailLimit: number;
  private readonly loadRepairedConversationKeys = new Set<string>();
  // Unparsed transcript head bytes from a tail load, validated pre-append.
  private readonly unreadTranscriptHeadBytesByKey = new Map<string, number>();
  private readonly transcriptMetadataByConversationKey = new Map<
    string,
    LocalConversationTranscriptMetadata
  >();
  private readonly conversationRecordJsonByKey = new Map<string, string>();
  private readonly sessionEntryIdsByConversationKey = new Map<
    string,
    Set<string>
  >();
  private readonly sessionEntryIdByMessageIdByConversationKey = new Map<
    string,
    Map<string, string>
  >();
  private readonly persistedMessageByMessageIdByConversationKey = new Map<
    string,
    Map<string, LocalMessage>
  >();
  private readonly lastSessionEntryIdByConversationKey = new Map<
    string,
    string | null
  >();
  private readonly compiledSystemPromptByConversationKey = new Map<
    string,
    LocalCompiledSystemPrompt
  >();
  private readonly messagesById = new Map<string, StoredMessage[]>();
  // Assistant ids with a stop_reason chunk (turn completed), for rollback.
  private readonly settledLocalMessageIds = new Set<string>();
  private conversationRecordsScanned = false;
  private conversationSeq = 0;
  private messageSeq = 0;
  private localMessageSeq = 0;

  constructor(
    private readonly defaultAgentId: string,
    options: LocalStoreOptions = {},
  ) {
    this.storageDir = options.storageDir;
    this.strictAgentAccess = options.strictAgentAccess === true;
    this.strictConversationAccess =
      options.strictConversationAccess ?? this.strictAgentAccess;
    this.defaultAgentName =
      options.defaultAgentName ?? DEFAULT_LOCAL_AGENT_NAME;
    this.defaultAgentModel = options.defaultAgentModel ?? DEFAULT_LOCAL_MODEL;
    this.defaultAgentModelSettings = {
      ...(options.defaultAgentModelSettings ?? {}),
    };
    this.modelSettingsForModel = options.modelSettingsForModel;
    this.conversationIdPrefix =
      options.conversationIdPrefix ?? DEFAULT_LOCAL_CONVERSATION_ID_PREFIX;
    this.storedMessageIdPrefix =
      options.storedMessageIdPrefix ?? DEFAULT_LOCAL_STORED_MESSAGE_ID_PREFIX;
    this.localMessageIdPrefix =
      options.localMessageIdPrefix ?? DEFAULT_LOCAL_UI_MESSAGE_ID_PREFIX;
    this.residentMessageTailLimit = Math.max(
      1,
      Math.floor(
        options.residentMessageTailLimit ?? DEFAULT_RESIDENT_MESSAGE_TAIL_LIMIT,
      ),
    );
    this.loadFromStorage();
    if (options.seedDefaultAgent !== false) {
      this.ensureAgent(this.defaultAgentId);
    }
  }

  retrieveAgent(agentId: string): AgentState {
    const existing = this.refreshAgentRecordFromStorage(agentId);
    if (!existing && !this.strictAgentAccess) return this.ensureAgent(agentId);
    if (!existing) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    return this.projectAgent(existing);
  }

  listAgents(body?: AgentListBody): { items: AgentState[] } {
    this.refreshLoadedAgentRecordsFromStorage();
    const bodyRecord = (body ?? {}) as Record<string, unknown>;
    const queryText = optionalString(bodyRecord.query_text)?.toLowerCase();
    const tags = isStringArray(bodyRecord.tags) ? bodyRecord.tags : [];
    const after = optionalString(bodyRecord.after);
    const limit = typeof bodyRecord.limit === "number" ? bodyRecord.limit : 20;
    let agents = [...this.agents.values()]
      .filter((agent) => !isHiddenLocalAgentRecord(agent))
      .map((agent) => this.projectAgent(agent));

    if (tags.length > 0) {
      agents = agents.filter((agent) =>
        tags.every((tag) => agent.tags?.includes(tag)),
      );
    }
    if (queryText) {
      agents = agents.filter((agent) => {
        const haystack = [agent.name, agent.description, agent.id, agent.model]
          .filter((value): value is string => typeof value === "string")
          .join("\n")
          .toLowerCase();
        return haystack.includes(queryText);
      });
    }
    agents.sort((a, b) => {
      const aDate =
        (a as { last_run_completion?: string | null }).last_run_completion ??
        "";
      const bDate =
        (b as { last_run_completion?: string | null }).last_run_completion ??
        "";
      return bDate.localeCompare(aDate);
    });
    if (after) {
      const afterIndex = agents.findIndex((agent) => agent.id === after);
      if (afterIndex >= 0) agents = agents.slice(afterIndex + 1);
    }

    return { items: agents.slice(0, limit) };
  }

  deleteAgent(agentId: string): void {
    if (this.strictAgentAccess && !this.agents.has(agentId)) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    this.agents.delete(agentId);
    this.agentRecordMtimeMsById.delete(agentId);
    this.loadConversationRecordsFromStorage();
    for (const [key, conversation] of [...this.conversations.entries()]) {
      if (conversation.agent_id === agentId) {
        this.conversations.delete(key);
        this.localMessagesByConversationKey.delete(key);
        this.loadedConversationKeys.delete(key);
        this.tailResidentConversationKeys.delete(key);
        this.residentTailStartIndexByConversationKey.delete(key);
        this.loadRepairedConversationKeys.delete(key);
        this.transcriptMetadataByConversationKey.delete(key);
        this.conversationRecordJsonByKey.delete(key);
        this.sessionEntryIdsByConversationKey.delete(key);
        this.sessionEntryIdByMessageIdByConversationKey.delete(key);
        this.persistedMessageByMessageIdByConversationKey.delete(key);
        this.lastSessionEntryIdByConversationKey.delete(key);
        if (this.storageDir) {
          rmSync(
            join(this.storageDir, "conversations", encodePathSegment(key)),
            {
              recursive: true,
              force: true,
            },
          );
        }
      }
    }
    if (this.storageDir) {
      rmSync(
        join(this.storageDir, "agents", `${encodePathSegment(agentId)}.json`),
        { force: true },
      );
    }
  }

  retrieveAgentRecord(agentId: string): LocalAgentRecord {
    let existing = this.refreshAgentRecordFromStorage(agentId);
    if (!existing && !this.strictAgentAccess) {
      this.ensureAgent(agentId);
      existing = this.agents.get(agentId);
    }
    if (!existing) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    return existing;
  }

  ensureAgent(agentId: string): AgentState {
    const existing = this.refreshAgentRecordFromStorage(agentId);
    if (existing) return this.projectAgent(existing);
    const agent = this.createDefaultAgentRecord(agentId);
    this.agents.set(agentId, agent);
    this.persistAgent(agentId);
    this.ensureConversation("default", agentId);
    return this.projectAgent(agent);
  }

  updateAgent(agentId: string, body: AgentUpdateBody): AgentState {
    const currentRecord = this.refreshAgentRecordFromStorage(agentId);
    if (!currentRecord) {
      if (this.strictAgentAccess) {
        throw new LocalBackendNotFoundError("Agent", agentId);
      }
      this.ensureAgent(agentId);
    }
    const existingRecord =
      currentRecord ??
      this.agents.get(agentId) ??
      this.createDefaultAgentRecord(agentId);
    const bodyRecord = body as Record<string, unknown>;
    const nextSystem =
      typeof bodyRecord.system === "string" ? bodyRecord.system : undefined;
    const systemChanged =
      nextSystem !== undefined && nextSystem !== existingRecord.system;
    const requestedModel = bodyRecord.model;
    const requestedModelSettings = supportedModelSettingsFromBody(bodyRecord);
    const nextModel =
      typeof requestedModel === "string" &&
      !shouldUseDefaultLocalModel(requestedModel)
        ? normalizeLocalModelHandle(requestedModel, requestedModelSettings)
        : typeof requestedModel === "string" && this.defaultAgentModel
          ? this.defaultAgentModel
          : undefined;
    const modelChanged =
      nextModel !== undefined && nextModel !== existingRecord.model;
    const nextModelDefaults = nextModel
      ? this.modelSettingsDefaultsForModel(nextModel)
      : undefined;
    const nextModelSettings = {
      ...(modelChanged ? {} : existingRecord.model_settings),
      ...requestedModelSettings,
      ...(modelChanged ? (nextModelDefaults ?? {}) : {}),
    };
    const updated = {
      ...existingRecord,
      ...(typeof bodyRecord.name === "string" && { name: bodyRecord.name }),
      ...((typeof bodyRecord.description === "string" ||
        bodyRecord.description === null) && {
        description: bodyRecord.description,
      }),
      ...(typeof bodyRecord.system === "string" && {
        system: bodyRecord.system,
      }),
      ...(isStringArray(bodyRecord.tags) && { tags: bodyRecord.tags }),
      ...(nextModel && { model: nextModel }),
      ...(typeof bodyRecord.hidden === "boolean" && {
        hidden: bodyRecord.hidden,
      }),
      model_settings: nextModelSettings,
    };
    this.agents.set(agentId, updated);
    this.persistAgent(agentId);
    if (systemChanged) {
      this.clearCompiledSystemPromptsForAgent(agentId);
    }
    return this.projectAgent(updated);
  }

  setAgentCompactionSettings(
    agentId: string,
    settings: Record<string, unknown> | null,
  ): AgentState {
    const existing = this.refreshAgentRecordFromStorage(agentId);
    if (!existing) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    const updated: LocalAgentRecord = {
      ...existing,
      compaction_settings: settings === null ? null : { ...settings },
    };
    this.agents.set(agentId, updated);
    this.persistAgent(agentId);
    return this.projectAgent(updated);
  }

  createAgent(body: AgentCreateBody): AgentState {
    const agent = this.createAgentRecord(body);
    const agentId = agent.id;
    this.agents.set(agentId, agent);
    this.persistAgent(agentId);
    this.ensureConversation("default", agentId);
    return this.projectAgent(agent);
  }

  private createDefaultAgentRecord(agentId: string): LocalAgentRecord {
    const agent = createDefaultAgentRecord(
      agentId,
      this.defaultAgentName,
      this.defaultAgentModel,
    );
    return {
      ...agent,
      model: this.defaultAgentModel,
      model_settings: {
        ...agent.model_settings,
        ...this.defaultAgentModelSettings,
      },
    };
  }

  private createAgentRecord(body: AgentCreateBody): LocalAgentRecord {
    const agent = createLocalAgentRecord(
      body,
      this.defaultAgentName,
      this.defaultAgentModel,
    );
    const bodyRecord = body as Record<string, unknown>;
    if (!shouldUseDefaultLocalModel(bodyRecord.model)) {
      return agent;
    }
    return {
      ...agent,
      model: this.defaultAgentModel,
      model_settings: {
        ...this.defaultAgentModelSettings,
        ...agent.model_settings,
      },
    };
  }

  private modelSettingsDefaultsForModel(
    model: string,
  ): Record<string, unknown> | undefined {
    return (
      this.modelSettingsForModel?.(model) ??
      (model === this.defaultAgentModel
        ? this.defaultAgentModelSettings
        : undefined)
    );
  }

  private projectableAgentRecord(record: LocalAgentRecord): LocalAgentRecord {
    const defaults = this.modelSettingsDefaultsForModel(record.model);
    if (!defaults || Object.keys(defaults).length === 0) return record;

    const contextWindowLimit = record.model_settings.context_window_limit;
    const defaultContextWindowLimit = defaults.context_window_limit;
    const shouldReplaceLegacyContextWindow =
      contextWindowLimit === LEGACY_LOCAL_CONTEXT_WINDOW_LIMIT &&
      typeof defaultContextWindowLimit === "number" &&
      defaultContextWindowLimit > LEGACY_LOCAL_CONTEXT_WINDOW_LIMIT;

    return {
      ...record,
      model_settings: {
        ...defaults,
        ...record.model_settings,
        ...(shouldReplaceLegacyContextWindow
          ? { context_window_limit: defaultContextWindowLimit }
          : {}),
      },
    };
  }

  retrieveConversation(conversationId: string, agentId?: string): Conversation {
    const existing = this.findConversation(conversationId, agentId);
    if (existing) return existing;
    if (this.strictConversationAccess) {
      throw new LocalBackendNotFoundError("Conversation", conversationId);
    }
    return this.ensureConversation(conversationId, agentId);
  }

  retrievePublicConversation(
    conversationId: string,
    agentId?: string,
  ): Conversation {
    const conversation = this.retrieveConversation(
      conversationId,
      agentId,
    ) as StoredConversation;
    return conversation.agent_free
      ? ({ ...conversation, agent_id: null } as unknown as Conversation)
      : conversation;
  }

  listConversations(body?: ConversationListBody): Conversation[] {
    this.loadConversationRecordsFromStorage();
    this.refreshLoadedConversationRecordsFromStorage();

    return listLocalConversations(this.conversations.values(), body).map(
      (conversation) =>
        (conversation as StoredConversation).agent_free
          ? ({ ...conversation, agent_id: null } as unknown as Conversation)
          : conversation,
    );
  }

  createConversation(body: ConversationCreateBody): Conversation {
    const agentId = body.agent_id ?? this.defaultAgentId;
    if (this.strictAgentAccess && !this.agents.has(agentId)) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    this.ensureAgent(agentId);
    const conversationId = this.nextConversationId();
    const conversation = this.withConversationModelDefaults(
      createLocalConversationRecord(conversationId, agentId, body),
    );
    const key = this.conversationKey(conversation.id, agentId);
    this.conversations.set(key, conversation);
    this.markNewConversationResident(key);
    this.persistConversationState(conversation.id, agentId);
    return conversation;
  }

  createEphemeralConversation(body: {
    model: string;
    system: string;
    model_settings?: Record<string, unknown>;
    context_window_limit?: number | null;
    parent_agent_id?: string | null;
    name?: string;
    is_subagent?: boolean;
  }): StoredConversation {
    // SDK queries create their app-server processes concurrently. UUID-backed
    // worker IDs avoid a cross-process exists-then-create race in numeric IDs.
    const conversationId = `local-conv-${randomUUID()}`;
    const executionAgentId =
      this.executionAgentIdForConversation(conversationId);
    const conversation = this.withConversationModelDefaults({
      ...createLocalConversationRecord(
        conversationId,
        executionAgentId,
        body as unknown as ConversationCreateBody,
      ),
      agent_free: true,
    });
    const key = this.conversationKey(conversation.id, executionAgentId);
    this.conversations.set(key, conversation);
    this.markNewConversationResident(key);
    this.persistConversationState(
      conversation.id,
      this.executionAgentIdForConversation(conversation.id),
    );
    return { ...conversation, agent_id: null } as unknown as StoredConversation;
  }

  isAgentFreeConversation(conversationId: string): boolean {
    return (
      (this.findConversation(conversationId) as StoredConversation | undefined)
        ?.agent_free === true
    );
  }

  retrieveExecutionAgentRecord(
    conversationId: string,
    agentId: string,
  ): LocalAgentRecord {
    const conversation = this.retrieveConversation(
      conversationId,
      agentId,
    ) as StoredConversation;
    if (!conversation.agent_free) {
      return this.retrieveAgentRecord(agentId);
    }
    return agentFreeExecutionRecord(
      conversation,
      this.executionAgentIdForConversation(conversationId),
    );
  }

  updateConversation(
    conversationId: string,
    body: ConversationUpdateBody,
  ): Conversation {
    if (conversationId === "default") {
      throw new Error("Default conversation cannot be updated");
    }

    const current = this.findConversation(conversationId);
    if (!current) {
      if (this.strictConversationAccess) {
        throw new LocalBackendNotFoundError("Conversation", conversationId);
      }
      const created = this.ensureConversation(conversationId);
      const updated = updateLocalConversationRecord(
        created,
        body,
        currentIsoTimestamp(),
      );
      const projected = this.withConversationModelDefaults(updated);
      this.conversations.set(
        this.conversationKey(conversationId, created.agent_id),
        projected,
      );
      this.persistConversationState(conversationId, created.agent_id);
      return this.retrievePublicConversation(conversationId, created.agent_id);
    }
    const updated = this.withConversationModelDefaults(
      updateLocalConversationRecord(current, body, currentIsoTimestamp()),
    );
    this.conversations.set(
      this.conversationKey(conversationId, current.agent_id),
      updated,
    );
    this.persistConversationState(conversationId, current.agent_id);
    return this.retrievePublicConversation(conversationId, current.agent_id);
  }

  private withConversationModelDefaults(
    conversation: StoredConversation,
  ): StoredConversation {
    const requestedModel = conversation.model;
    if (typeof requestedModel !== "string") return conversation;
    const normalizedRequestedModel = normalizeLocalModelHandle(
      requestedModel,
      isRecord(conversation.model_settings) ? conversation.model_settings : {},
    );
    const defaults = this.modelSettingsDefaultsForModel(
      normalizedRequestedModel,
    );
    if (!defaults || Object.keys(defaults).length === 0) return conversation;
    const existingSettings = isRecord(conversation.model_settings)
      ? conversation.model_settings
      : {};
    return {
      ...conversation,
      model: normalizedRequestedModel,
      model_settings: {
        ...defaults,
        ...existingSettings,
      },
    };
  }

  forkConversation(
    conversationId: string,
    options: { agentId?: string; hidden?: boolean; messageId?: string } = {},
  ): { id: string } {
    const source = this.findConversation(
      conversationId,
      conversationId === "default" ? options.agentId : undefined,
    );
    if (!source) {
      throw new LocalBackendNotFoundError("Conversation", conversationId);
    }
    const targetAgentId = options.agentId ?? source.agent_id;
    if (this.strictAgentAccess && !this.agents.has(targetAgentId)) {
      throw new LocalBackendNotFoundError("Agent", targetAgentId);
    }
    this.ensureAgent(targetAgentId);
    const sourceMessages = selectLocalMessagesForFork(
      this.localMessagesForConversation(source.id, source.agent_id),
      options.messageId,
      source.agent_id,
      source.id,
    );
    if (!sourceMessages) {
      throw new LocalBackendNotFoundError("Message", options.messageId ?? "");
    }
    const forkedConversationId = this.nextConversationId(targetAgentId);
    const forked = createLocalConversationRecord(
      forkedConversationId,
      targetAgentId,
      {
        summary: source.summary ?? null,
        ...(source.model !== undefined ? { model: source.model } : {}),
        ...(source.model_settings !== undefined
          ? { model_settings: source.model_settings }
          : {}),
        ...(typeof options.hidden === "boolean"
          ? { hidden: options.hidden }
          : {}),
      } as Partial<ConversationCreateBody>,
    );
    const forkedMessages = sourceMessages.map((message) =>
      this.cloneLocalMessageForConversation(message, forked.id, targetAgentId),
    );
    forked.in_context_message_ids = forkedMessages.map((message) => message.id);
    const targetKey = this.conversationKey(forked.id, targetAgentId);
    this.conversations.set(targetKey, forked);
    this.localMessagesByConversationKey.set(targetKey, forkedMessages);
    this.loadedConversationKeys.add(targetKey);
    this.persistConversationState(forked.id, targetAgentId, {
      transcript: "rewrite",
    });
    // Fork transcript fully persisted: keep only the bounded tail resident.
    this.demoteConversationToResidentTail(targetKey);
    return { id: forked.id };
  }

  appendTurnInput(
    conversationId: string,
    body: ConversationMessageCreateBody | ConversationMessageStreamBody,
  ): StoredTurnInput {
    const bodyWithAgent = body as {
      agent_id?: string;
      messages?: Array<Record<string, unknown>>;
    };
    const existingConversation = this.findConversation(conversationId);
    const agentId =
      bodyWithAgent.agent_id ?? this.agentIdForConversation(conversationId);
    const isAgentFree = existingConversation?.agent_free === true;
    if (!isAgentFree) {
      if (this.strictAgentAccess && !this.agents.has(agentId)) {
        throw new LocalBackendNotFoundError("Agent", agentId);
      }
      this.ensureAgent(agentId);
    }
    if (
      this.strictConversationAccess &&
      !this.findConversation(conversationId, agentId)
    ) {
      throw new LocalBackendNotFoundError("Conversation", conversationId);
    }
    this.ensureConversation(conversationId, agentId);

    for (const message of bodyWithAgent.messages ?? []) {
      if (message.type === "approval") {
        this.applyApprovalResults(
          conversationId,
          agentId,
          Array.isArray(message.approvals) ? message.approvals : [],
        );
        continue;
      }
      if (message.role === "user") {
        this.appendUserLocalMessage(conversationId, agentId, message);
      }
    }

    return { agentId, conversationId };
  }

  appendStreamChunk(
    conversationId: string,
    agentId: string,
    chunk: LettaStreamingResponse,
  ): LettaStreamingResponse {
    const localMessageSnapshot = getAttachedLocalMessage(chunk);
    if (isLocalStateChunkOnly(chunk)) {
      if (localMessageSnapshot) {
        this.applyFinalAssistantMessage(
          conversationId,
          agentId,
          localMessageSnapshot,
        );
      }
      return chunk;
    }

    const messageType = (chunk as { message_type?: unknown })?.message_type;
    if (messageType === "stop_reason") {
      this.persistPendingAssistantMessage(conversationId, agentId);
      return chunk;
    }
    if (typeof messageType !== "string") {
      return chunk;
    }

    const storedChunk = this.createStoredChunk(
      conversationId,
      agentId,
      toStoredOutputFields(chunk as unknown as Record<string, unknown>),
    );
    this.applyVisibleChunkToLocalMessages(
      conversationId,
      agentId,
      chunk,
      storedChunk,
    );
    return canonicalizeLocalStreamChunk(
      chunk,
      storedChunk,
      this.residentLocalMessagesForConversation(conversationId, agentId).at(-1),
    ) as unknown as LettaStreamingResponse;
  }

  listLocalMessages(conversationId: string, agentId?: string): LocalMessage[] {
    const resolvedAgentId =
      agentId ?? this.agentIdForConversation(conversationId);
    this.ensureConversation(conversationId, resolvedAgentId);
    return this.localMessagesForConversation(
      conversationId,
      resolvedAgentId,
    ).map(cloneLocalMessage);
  }

  settleInterruptedToolCalls(
    conversationIdOrAgentId: string,
    options: { agentId?: string; reason?: string } = {},
  ): number {
    const targets = this.toolSettlementTargets(
      conversationIdOrAgentId,
      options.agentId,
    );
    let settledCount = 0;
    for (const target of targets) {
      settledCount += this.settleInterruptedToolCallsForConversation(
        target.conversationId,
        target.agentId,
        options.reason ?? INTERRUPTED_BY_USER,
      );
    }
    return settledCount;
  }

  resolveAgentIdForConversation(conversationId: string): string {
    return this.agentIdForConversation(conversationId);
  }

  getCompiledSystemPrompt(
    conversationId: string,
    agentId: string,
  ): LocalCompiledSystemPrompt | undefined {
    this.findConversation(conversationId, agentId);
    const key = this.conversationKey(conversationId, agentId);
    return this.compiledSystemPromptByConversationKey.get(key);
  }

  setCompiledSystemPrompt(
    conversationId: string,
    agentId: string,
    prompt: LocalCompiledSystemPrompt,
  ): void {
    const conversation = this.ensureConversation(conversationId, agentId);
    const key = this.conversationKey(conversation.id, agentId);
    this.compiledSystemPromptByConversationKey.set(key, prompt);
    this.persistCompiledSystemPrompt(conversation.id, agentId);
  }

  clearCompiledSystemPromptsForAgent(agentId: string): void {
    this.loadConversationRecordsFromStorage();
    for (const [key, conversation] of this.conversations.entries()) {
      if (conversation.agent_id !== agentId) continue;
      this.compiledSystemPromptByConversationKey.delete(key);
      if (this.storageDir) {
        rmSync(
          join(
            this.storageDir,
            "conversations",
            encodePathSegment(key),
            "system-prompt.json",
          ),
          { force: true },
        );
      }
    }
  }

  listConversationMessages(
    conversationId: string,
    body?: ConversationMessageListBody,
  ): StoredMessage[] {
    const agentId =
      (body as { agent_id?: string } | undefined)?.agent_id ??
      this.agentIdForConversation(conversationId);
    const conversation = this.findConversation(conversationId, agentId);
    if (
      this.strictAgentAccess &&
      !conversation?.agent_free &&
      !this.agents.has(agentId)
    ) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    if (!conversation) {
      if (this.strictConversationAccess) {
        throw new LocalBackendNotFoundError("Conversation", conversationId);
      }
      this.ensureConversation(conversationId, agentId);
    }
    const tailMessages = this.projectTailMessagesForConversation(
      conversationId,
      agentId,
      body,
    );
    if (tailMessages) return tailMessages;

    const messages = this.projectedMessagesForConversation(
      conversationId,
      agentId,
    );
    return this.applyListOptions(messages, body);
  }

  listAgentMessages(
    agentId: string,
    body?: AgentMessageListBody,
  ): StoredMessage[] {
    if (this.strictAgentAccess && !this.agents.has(agentId)) {
      throw new LocalBackendNotFoundError("Agent", agentId);
    }
    const conversationId =
      (body as { conversation_id?: string } | undefined)?.conversation_id ??
      "default";
    return this.listConversationMessages(conversationId, {
      ...(body as Record<string, unknown> | undefined),
      agent_id: agentId,
    } as ConversationMessageListBody);
  }

  retrieveMessage(messageId: string): StoredMessage[] {
    let messages = this.messagesById.get(messageId) ?? [];
    if (messages.length === 0) {
      this.rebuildMessageIndex();
      messages = this.messagesById.get(messageId) ?? [];
    }
    if (messages.length === 0) {
      this.indexMessageFromTranscriptTail(messageId);
      messages = this.messagesById.get(messageId) ?? [];
    }
    if (messages.length === 0) {
      this.loadConversationContainingMessage(messageId);
      messages = this.messagesById.get(messageId) ?? [];
    }
    if (messages.length === 0 && this.strictConversationAccess) {
      throw new LocalBackendNotFoundError("Message", messageId);
    }
    return [...messages];
  }

  compactConversationAll(input: {
    conversationId: string;
    agentId: string;
    summary: string;
    packedSummary: string;
    stats?: LocalCompactionStats;
    remainingMessages?: LocalMessage[];
  }): LocalCompactionStoreResult {
    const conversation = this.ensureConversation(
      input.conversationId,
      input.agentId,
    );
    const key = this.conversationKey(conversation.id, input.agentId);
    // Ensure the resident tail first; validate its unread head pre-rewrite.
    this.residentLocalMessagesForConversation(conversation.id, input.agentId);
    this.validateUnreadTranscriptHeadOnce(key);
    const previousMessages = this.localMessagesForConversation(
      conversation.id,
      input.agentId,
    );
    const id = this.nextLocalMessageId();
    const date = this.currentLocalMessageDate();
    const summaryMessage: LocalMessage = {
      id,
      role: "user",
      metadata: {
        created_at: date,
        updated_at: date,
        agent_id: input.agentId,
        conversation_id: conversation.id,
        compaction: {
          summary: input.summary,
          ...(input.stats ? { stats: input.stats } : {}),
        },
      },
      content: [{ type: "text", text: input.packedSummary }],
      timestamp: timestampFromIso(date),
    };
    const compactedMessages = [
      summaryMessage,
      ...(input.remainingMessages ?? []).map(cloneLocalMessage),
    ];
    const inContextIds = compactedMessages.map((message) => message.id);
    const numMessagesAfter = compactedMessages.length;
    conversation.in_context_message_ids = inContextIds;
    this.setResidentConversationMessages(key, compactedMessages);
    conversation.last_message_at = date;
    conversation.updated_at = date;
    this.conversations.set(key, conversation);
    this.persistConversationState(conversation.id, input.agentId, {
      transcript: "append-compaction",
      compaction: {
        summaryMessage,
        summary: input.summary,
        firstKeptMessageId: input.remainingMessages?.[0]?.id,
        previousMessages,
        ...(input.stats ? { stats: input.stats } : {}),
      },
    });
    this.rebuildMessageIndex();
    return {
      numMessagesBefore: previousMessages.length,
      numMessagesAfter,
      summaryMessage: cloneLocalMessage(summaryMessage),
    };
  }

  private appendUserLocalMessage(
    conversationId: string,
    agentId: string,
    message: Record<string, unknown>,
  ): LocalMessage {
    const conversation = this.ensureConversation(conversationId, agentId);
    const date = this.currentLocalMessageDate();
    const localMessage: LocalMessage = {
      id: this.nextLocalMessageId(),
      role: "user",
      otid: optionalString(message.otid ?? message.client_message_id),
      metadata: {
        created_at: date,
        updated_at: date,
        agent_id: agentId,
        conversation_id: conversation.id,
      },
      content: this.localContentFromInputContent(
        normalizeContent(message.content),
      ),
      timestamp: timestampFromIso(date),
    };
    this.pushLocalMessage(conversation.id, agentId, localMessage);
    return localMessage;
  }

  private applyVisibleChunkToLocalMessages(
    conversationId: string,
    agentId: string,
    chunk: LettaStreamingResponse,
    storedChunk: StoredMessage,
  ): void {
    if (chunk.message_type === "reasoning_message") {
      const reasoning = (chunk as { reasoning?: unknown }).reasoning;
      if (typeof reasoning === "string") {
        this.appendAssistantReasoning(
          conversationId,
          agentId,
          reasoning,
          storedChunk,
        );
      }
      return;
    }

    if (chunk.message_type === "assistant_message") {
      const content = (chunk as { content?: unknown }).content;
      const parts = Array.isArray(content)
        ? content
        : textContent(textFromContent(content));
      for (const part of parts) {
        if (!isRecord(part)) continue;
        if (part.type === "text" && typeof part.text === "string") {
          this.appendAssistantText(
            conversationId,
            agentId,
            part.text,
            storedChunk,
          );
          continue;
        }
        if (part.type === "reasoning" && typeof part.text === "string") {
          this.appendAssistantReasoning(
            conversationId,
            agentId,
            part.text,
            storedChunk,
          );
        }
      }
      return;
    }

    if (chunk.message_type === "approval_request_message") {
      const toolCall = this.toolCallFromChunk(chunk);
      if (toolCall) {
        this.appendAssistantToolCall(
          conversationId,
          agentId,
          toolCall,
          storedChunk,
        );
      }
    }
  }

  private applyFinalAssistantMessage(
    conversationId: string,
    agentId: string,
    message: LocalMessage,
  ): void {
    if (message.role !== "assistant") return;
    const conversation = this.ensureConversation(conversationId, agentId);
    const key = this.conversationKey(conversation.id, agentId);
    const localMessages = this.residentLocalMessagesForConversation(
      conversation.id,
      agentId,
    );
    const last = localMessages.at(-1);
    const existingAssistant = last?.role === "assistant" ? last : undefined;
    const id = existingAssistant?.id ?? this.nextLocalMessageId();
    const date =
      existingAssistant?.metadata?.created_at ?? this.currentLocalMessageDate();
    const snapshot = cloneLocalMessage(message) as LocalAssistantMessage;
    const localMessage: LocalAssistantMessage = {
      ...snapshot,
      id,
      role: "assistant",
      content: mergeSnapshotContentWithExistingToolCalls(
        snapshot.content,
        existingAssistant?.content ?? [],
      ),
      metadata: {
        ...existingAssistant?.metadata,
        ...snapshot.metadata,
        created_at: date,
        updated_at: date,
        agent_id: agentId,
        conversation_id: conversation.id,
      },
    };
    if (existingAssistant) {
      localMessages[localMessages.length - 1] = localMessage;
    } else {
      localMessages.push(localMessage);
    }
    this.localMessagesByConversationKey.set(key, localMessages);
    this.trimResidentConversationTail(key);
    this.touchConversationForLocalMessage(
      conversation.id,
      agentId,
      localMessage,
    );
    this.persistConversationState(conversation.id, agentId, {
      transcript: "append",
      message: localMessage,
    });
  }

  private appendAssistantText(
    conversationId: string,
    agentId: string,
    text: string,
    storedChunk: StoredMessage,
  ): void {
    const message = this.assistantLocalMessageForAppend(
      conversationId,
      agentId,
      storedChunk,
    );
    const lastContent = message.content.at(-1);
    if (lastContent?.type === "text") {
      lastContent.text += text;
    } else {
      message.content.push({ type: "text", text });
    }
    this.touchLocalMessage(message, storedChunk);
  }

  private appendAssistantReasoning(
    conversationId: string,
    agentId: string,
    text: string,
    storedChunk: StoredMessage,
  ): void {
    const message = this.assistantLocalMessageForAppend(
      conversationId,
      agentId,
      storedChunk,
    );
    const lastContent = message.content.at(-1);
    if (lastContent?.type === "thinking") {
      lastContent.thinking += text;
    } else {
      message.content.push({ type: "thinking", thinking: text });
    }
    this.touchLocalMessage(message, storedChunk);
  }

  private appendAssistantToolCall(
    conversationId: string,
    agentId: string,
    toolCall: { toolCallId: string; toolName: string; input: unknown },
    storedChunk: StoredMessage,
  ): void {
    const message = this.assistantLocalMessageForAppend(
      conversationId,
      agentId,
      storedChunk,
    );
    const nextToolCall: LocalToolCall = {
      type: "toolCall",
      id: toolCall.toolCallId,
      name: toolCall.toolName,
      arguments: localToolArgumentsFromUnknown(toolCall.input),
    };
    const existing = this.findToolCall(
      conversationId,
      agentId,
      toolCall.toolCallId,
    );
    if (existing) {
      Object.assign(existing.content, nextToolCall);
    } else {
      message.content.push(nextToolCall);
    }
    this.touchLocalMessage(message, storedChunk);
  }

  private toolResultContentFromUnknown(
    value: unknown,
  ): LocalToolResultMessage["content"] {
    if (Array.isArray(value)) {
      const content: LocalToolResultMessage["content"] = [];
      for (const part of value) {
        if (!isRecord(part)) continue;
        if (part.type === "text" && typeof part.text === "string") {
          content.push({ type: "text", text: part.text });
          continue;
        }
        const image = localImageContentFromLegacyImage(part);
        if (image) content.push(image);
      }
      if (content.length > 0) return content;
    }
    return [{ type: "text", text: textFromContent(value) }];
  }

  private findToolResult(
    conversationId: string,
    agentId: string,
    toolCallId: string,
  ): LocalToolResultMessage | undefined {
    // Only consulted for in-window tool calls; results follow their call.
    return this.residentLocalMessagesForConversation(
      conversationId,
      agentId,
    ).find(
      (message): message is LocalToolResultMessage =>
        message.role === "toolResult" && message.toolCallId === toolCallId,
    );
  }

  private appendToolResultMessage(input: {
    conversationId: string;
    agentId: string;
    toolCall: LocalToolCall;
    content: LocalToolResultMessage["content"];
    isError: boolean;
  }): void {
    if (
      this.findToolResult(
        input.conversationId,
        input.agentId,
        input.toolCall.id,
      )
    ) {
      return;
    }
    const conversation = this.ensureConversation(
      input.conversationId,
      input.agentId,
    );
    const id = this.nextLocalMessageId();
    const date = this.currentLocalMessageDate();
    const message: LocalToolResultMessage = {
      id,
      role: "toolResult",
      toolCallId: input.toolCall.id,
      toolName: input.toolCall.name,
      content: input.content,
      isError: input.isError,
      timestamp: timestampFromIso(date),
      metadata: {
        created_at: date,
        updated_at: date,
        agent_id: input.agentId,
        conversation_id: conversation.id,
      },
    };
    this.pushLocalMessage(conversation.id, input.agentId, message);
  }

  private applyApprovalResults(
    conversationId: string,
    agentId: string,
    approvals: unknown[],
  ): void {
    for (const approval of approvals) {
      if (!isRecord(approval)) continue;
      const toolCallId = approval.tool_call_id;
      if (typeof toolCallId !== "string") continue;
      const match = this.findToolCall(conversationId, agentId, toolCallId);
      if (!match) continue;
      if (this.findToolResult(conversationId, agentId, toolCallId)) continue;

      if (approval.type === "approval" && approval.approve === false) {
        this.appendToolResultMessage({
          conversationId,
          agentId,
          toolCall: match.content,
          content: [
            {
              type: "text",
              text:
                typeof approval.reason === "string"
                  ? approval.reason
                  : "Tool execution denied.",
            },
          ],
          isError: true,
        });
        continue;
      }

      if (approval.type !== "tool") continue;
      this.appendToolResultMessage({
        conversationId,
        agentId,
        toolCall: match.content,
        content: this.toolResultContentFromUnknown(approval.tool_return),
        isError: false,
      });
    }
  }

  private settleInterruptedToolCallsForConversation(
    conversationId: string,
    agentId: string,
    reason: string,
  ): number {
    const conversation = this.findConversation(conversationId, agentId);
    if (!conversation) return 0;

    this.rollbackUnpersistedTrailingAssistantMessage(conversation, agentId);

    // Unsettled tool calls only exist at the tail; results follow their call.
    const messages = this.residentLocalMessagesForConversation(
      conversation.id,
      agentId,
    );
    let settledCount = 0;
    for (const message of [...messages]) {
      if (message.role !== "assistant") continue;
      for (const content of message.content) {
        if (!isLocalToolCallContent(content)) continue;
        if (this.findToolResult(conversation.id, agentId, content.id)) continue;
        this.appendToolResultMessage({
          conversationId: conversation.id,
          agentId,
          toolCall: content,
          content: [{ type: "text", text: reason }],
          isError: true,
        });
        settledCount += 1;
      }
    }

    if (settledCount > 0) this.rebuildMessageIndex();
    return settledCount;
  }

  private rollbackUnpersistedTrailingAssistantMessage(
    conversation: StoredConversation,
    agentId: string,
  ): void {
    const key = this.conversationKey(conversation.id, agentId);
    const messages = this.residentLocalMessagesForConversation(
      conversation.id,
      agentId,
    );
    const last = messages.at(-1);
    if (last?.role !== "assistant") return;
    // stop_reason means the turn completed; disk stores also check the index.
    if (this.settledLocalMessageIds.has(last.id)) return;
    if (this.sessionEntryIdsByMessageId(key).has(last.id)) return;

    messages.pop();
    this.localMessagesByConversationKey.set(key, messages);
    conversation.in_context_message_ids =
      conversation.in_context_message_ids.filter((id) => id !== last.id);
    const previousLastMessage = messages.at(-1);
    conversation.last_message_at = previousLastMessage
      ? localMessageDate(
          previousLastMessage,
          conversation.last_message_at ?? currentIsoTimestamp(),
        )
      : conversation.created_at;
    conversation.updated_at = currentIsoTimestamp();
    this.conversations.set(key, conversation);
    this.persistConversationState(conversation.id, agentId, {
      transcript: "skip",
    });
    this.rebuildMessageIndex();
  }

  private findToolCall(
    conversationId: string,
    agentId: string,
    toolCallId: string,
  ):
    | { message: LocalAssistantMessage; content: LocalToolCallContent }
    | undefined {
    // Tool calls are only matched here while pending or interrupted (tail).
    const messages = this.residentLocalMessagesForConversation(
      conversationId,
      agentId,
    );
    for (
      let messageIndex = messages.length - 1;
      messageIndex >= 0;
      messageIndex--
    ) {
      const message = messages[messageIndex];
      if (!message || message.role !== "assistant") continue;
      for (
        let contentIndex = message.content.length - 1;
        contentIndex >= 0;
        contentIndex--
      ) {
        const content = message.content[contentIndex];
        if (
          content &&
          isLocalToolCallContent(content) &&
          content.id === toolCallId
        ) {
          return { message, content };
        }
      }
    }
    return undefined;
  }

  private assistantLocalMessageForAppend(
    conversationId: string,
    agentId: string,
    _storedChunk: StoredMessage,
  ): LocalAssistantMessage {
    const conversation = this.ensureConversation(conversationId, agentId);
    const key = this.conversationKey(conversation.id, agentId);
    const messages = this.residentLocalMessagesForConversation(
      conversation.id,
      agentId,
    );
    const last = messages.at(-1);
    if (last?.role === "assistant") {
      return last;
    }

    const id = this.nextLocalMessageId();
    const date = this.currentLocalMessageDate();
    const message: LocalAssistantMessage = {
      id,
      role: "assistant",
      metadata: {
        created_at: date,
        updated_at: date,
        agent_id: agentId,
        conversation_id: conversation.id,
      },
      content: [],
      api: "local",
      provider: "local",
      model: "local",
      usage: emptyLocalUsage(),
      stopReason: "stop",
      timestamp: timestampFromIso(date),
    };
    messages.push(message);
    this.localMessagesByConversationKey.set(key, messages);
    this.trimResidentConversationTail(key);
    this.touchConversationForLocalMessage(conversation.id, agentId, message);
    return message;
  }

  private touchLocalMessage(
    message: LocalMessage,
    storedChunk: StoredMessage,
  ): void {
    message.metadata = {
      ...message.metadata,
      updated_at: storedChunk.date,
      agent_id: storedChunk.agent_id,
      conversation_id: storedChunk.conversation_id,
    };
    this.touchConversationForLocalMessage(
      storedChunk.conversation_id,
      storedChunk.agent_id,
      message,
    );
    this.persistConversationState(
      storedChunk.conversation_id,
      storedChunk.agent_id,
      {
        transcript: "skip",
      },
    );
  }

  private toolCallFromChunk(
    chunk: LettaStreamingResponse,
  ): { toolCallId: string; toolName: string; input: unknown } | undefined {
    const chunkWithTools = chunk as unknown as {
      tool_call?: unknown;
      tool_calls?: unknown;
    };
    const toolCall =
      (isRecord(chunkWithTools.tool_call) && chunkWithTools.tool_call) ||
      (Array.isArray(chunkWithTools.tool_calls) &&
      isRecord(chunkWithTools.tool_calls[0])
        ? chunkWithTools.tool_calls[0]
        : undefined);
    if (!toolCall) return undefined;
    const toolCallId = toolCall.tool_call_id;
    const toolName = toolCall.name;
    if (typeof toolCallId !== "string" || typeof toolName !== "string") {
      return undefined;
    }
    return {
      toolCallId,
      toolName,
      input: parseToolInput(toolCall.arguments),
    };
  }

  private createStoredChunk(
    conversationId: string,
    agentId: string,
    fields: Record<string, unknown>,
  ): StoredMessage {
    const conversation = this.ensureConversation(conversationId, agentId);
    this.messageSeq += 1;
    return {
      id: `${this.storedMessageIdPrefix}${this.messageSeq}`,
      date: currentIsoTimestamp(),
      agent_id: agentId,
      conversation_id: conversation.id,
      ...fields,
    } as StoredMessage;
  }

  private applyListOptions(
    messages: StoredMessage[],
    body?: ConversationMessageListBody | AgentMessageListBody,
  ): StoredMessage[] {
    let items = messages;
    const includedMessageTypes = getIncludedMessageTypes(body);
    if (includedMessageTypes) {
      items = items.filter((message) =>
        includedMessageTypes.has(message.message_type),
      );
    }

    const before = getCursor(body, "before");
    if (before) {
      const beforeIndex = items.findIndex((message) => message.id === before);
      if (beforeIndex >= 0) {
        items = items.slice(0, beforeIndex);
      }
    }

    const after = getCursor(body, "after");
    if (after) {
      const afterIndex = items.findIndex((message) => message.id === after);
      if (afterIndex >= 0) {
        items = items.slice(afterIndex + 1);
      }
    }

    if (getListOrder(body) === "desc") {
      items = [...items].reverse();
    } else {
      items = [...items];
    }

    const limit = getListLimit(body);
    return limit === undefined ? items : items.slice(0, limit);
  }

  private projectLocalMessages(
    localMessages: readonly LocalMessage[],
    agentId: string,
    conversationId: string,
    options: { sourceStartIndex?: number; updateIndex?: boolean } = {},
  ): StoredMessage[] {
    const messages: StoredMessage[] = [];
    const sourceStartIndex = options.sourceStartIndex ?? 0;
    for (let index = 0; index < localMessages.length; index++) {
      const localMessage = localMessages[index];
      if (!localMessage) continue;
      const sourceIndex = sourceStartIndex + index;
      const projected = projectLocalMessageAtSourceIndex(
        localMessage,
        agentId,
        conversationId,
        sourceIndex,
      );
      messages.push(...projected);
      if (options.updateIndex === false) continue;
      for (const [lookupKey, lookupMessages] of projectedMessageLookupKeys(
        localMessage,
        projected,
      )) {
        this.messagesById.set(lookupKey, lookupMessages);
      }
    }
    return messages;
  }

  /**
   * Index only the projections of the message matching messageId within a
   * paged list, so deep retrieveMessage scans never pin a whole transcript.
   */
  private indexMatchingMessageInList(
    localMessages: readonly LocalMessage[],
    agentId: string,
    conversationId: string,
    messageId: string,
    sourceStartIndex: number,
  ): boolean {
    for (let index = 0; index < localMessages.length; index += 1) {
      const localMessage = localMessages[index];
      if (!localMessage) continue;
      const projected = projectLocalMessageAtSourceIndex(
        localMessage,
        agentId,
        conversationId,
        sourceStartIndex + index,
      );
      const lookupEntries = projectedMessageLookupKeys(localMessage, projected);
      if (!lookupEntries.some(([lookupKey]) => lookupKey === messageId)) {
        continue;
      }
      for (const [lookupKey, lookupMessages] of lookupEntries) {
        this.messagesById.set(lookupKey, lookupMessages);
      }
      return true;
    }
    return false;
  }

  private projectTailMessagesForConversation(
    conversationId: string,
    agentId: string,
    body?: ConversationMessageListBody,
  ): StoredMessage[] | undefined {
    const limit = getListLimit(body);
    if (limit === undefined || getListOrder(body) !== "desc") return undefined;
    if (getCursor(body, "after")) return undefined;

    const key = this.conversationKey(conversationId, agentId);
    if (this.loadedConversationKeys.has(key)) return undefined;
    const metadata = this.validateTranscriptMetadata(key);
    if (!metadata || metadata.requiresFullTimestampRepair) return undefined;

    const before = getCursor(body, "before");
    let maxBytes = 64 * 1024;
    for (;;) {
      const tail = readJsonlFileSuffix<unknown>(
        metadata.messagesPath,
        maxBytes,
      );
      const conversation = this.conversations.get(key);
      const { transcript, messages: normalizedMessages } =
        localTranscriptTailMessages(
          tail.items,
          metadata.messageFormat,
          conversation?.in_context_message_ids ?? [],
          this.storageDir ?? "",
          metadata.conversationDir,
        );
      const persistedIds =
        this.sessionEntryIdByMessageIdByConversationKey.get(key);
      const projected = this.projectLocalMessages(
        overlayResidentLocalMessageSuffix(
          normalizedMessages,
          this.localMessagesByConversationKey.get(key) ?? [],
          (messageId) => persistedIds?.has(messageId) === true,
        ),
        agentId,
        conversationId,
        { sourceStartIndex: transcript.sourceStartIndex, updateIndex: false },
      );
      const cursorFound =
        !before || projected.some((message) => message.id === before);
      const items = this.applyListOptions(projected, body);
      if (cursorFound && (items.length >= limit || tail.reachedStart)) {
        return items;
      }
      if (tail.reachedStart) return items;
      maxBytes *= 2;
    }
  }

  private projectedMessagesForConversation(
    conversationId: string,
    agentId: string,
  ): StoredMessage[] {
    const key = this.conversationKey(conversationId, agentId);
    const conversation = this.conversations.get(key);
    const resolvedConversationId = conversation?.id ?? conversationId;
    const localMessages = this.localMessagesForConversation(
      resolvedConversationId,
      agentId,
    );
    return this.projectLocalMessages(
      localMessages,
      agentId,
      resolvedConversationId,
      // Tail-resident conversations page projections, not index them.
      { updateIndex: this.loadedConversationKeys.has(key) },
    );
  }

  private rebuildMessageIndex(): void {
    this.loadConversationRecordsFromStorage();
    this.messagesById.clear();
    for (const conversation of this.conversations.values()) {
      const key = this.conversationKey(conversation.id, conversation.agent_id);
      const fullyResident = this.loadedConversationKeys.has(key);
      if (!fullyResident && !this.tailResidentConversationKeys.has(key)) {
        continue;
      }
      // Re-project only the resident window; older messages page on demand.
      const resident = this.localMessagesByConversationKey.get(key) ?? [];
      this.projectLocalMessages(
        resident,
        conversation.agent_id,
        conversation.id,
        {
          sourceStartIndex: fullyResident
            ? 0
            : (this.residentTailStartIndexByConversationKey.get(key) ?? 0),
        },
      );
    }
  }

  private loadConversationContainingMessage(messageId: string): void {
    this.loadConversationRecordsFromStorage();
    const sourceMessageId = sourceLocalMessageIdFromStoredMessageId(messageId);
    for (const conversation of this.conversations.values()) {
      const key = this.conversationKey(conversation.id, conversation.agent_id);
      if (this.loadedConversationKeys.has(key)) continue;
      if (
        !conversation.in_context_message_ids.includes(sourceMessageId) &&
        !conversation.in_context_message_ids.includes(messageId)
      ) {
        continue;
      }
      if (this.indexMessageFromConversationFullRead(conversation, messageId)) {
        return;
      }
    }

    for (const conversation of this.conversations.values()) {
      const key = this.conversationKey(conversation.id, conversation.agent_id);
      if (this.loadedConversationKeys.has(key)) continue;
      if (this.indexMessageFromConversationFullRead(conversation, messageId)) {
        return;
      }
    }
  }

  /**
   * Page the full transcript from disk and index only the retrieved
   * message; nothing stays resident.
   */
  private indexMessageFromConversationFullRead(
    conversation: StoredConversation,
    messageId: string,
  ): boolean {
    const messages = this.localMessagesForConversation(
      conversation.id,
      conversation.agent_id,
    );
    return this.indexMatchingMessageInList(
      messages,
      conversation.agent_id,
      conversation.id,
      messageId,
      0,
    );
  }

  private indexMessageFromTranscriptTail(messageId: string): boolean {
    this.loadConversationRecordsFromStorage();
    const sourceMessageId = sourceLocalMessageIdFromStoredMessageId(messageId);
    for (const conversation of this.conversations.values()) {
      const key = this.conversationKey(conversation.id, conversation.agent_id);
      if (this.loadedConversationKeys.has(key)) continue;
      if (
        !conversation.in_context_message_ids.includes(sourceMessageId) &&
        !conversation.in_context_message_ids.includes(messageId)
      ) {
        continue;
      }
      if (this.indexMessageFromConversationTail(key, conversation, messageId)) {
        return true;
      }
    }
    return false;
  }

  private indexMessageFromConversationTail(
    key: string,
    conversation: StoredConversation,
    messageId: string,
  ): boolean {
    const metadata = this.validateTranscriptMetadata(key);
    if (!metadata || metadata.requiresFullTimestampRepair) return false;

    let maxBytes = 64 * 1024;
    for (;;) {
      const tail = readJsonlFileSuffix<unknown>(
        metadata.messagesPath,
        maxBytes,
      );
      const { transcript, messages: normalizedMessages } =
        localTranscriptTailMessages(
          tail.items,
          metadata.messageFormat,
          conversation.in_context_message_ids,
          this.storageDir ?? "",
          metadata.conversationDir,
        );
      if (
        this.indexMatchingMessageInList(
          normalizedMessages,
          conversation.agent_id,
          conversation.id,
          messageId,
          transcript.sourceStartIndex,
        )
      ) {
        return true;
      }
      if (tail.reachedStart) return false;
      maxBytes *= 2;
    }
  }

  /**
   * Full logical message list for readers that need the whole history
   * (executor, compaction, fork, export). Serves from the resident array
   * when fully resident, else pages disk and merges the resident tail.
   * Fresh array; mutation paths use residentLocalMessagesForConversation.
   */
  private localMessagesForConversation(
    conversationId: string,
    agentId: string,
  ): LocalMessage[] {
    this.findConversation(conversationId, agentId);
    const key = this.conversationKey(conversationId, agentId);
    const resident = this.localMessagesByConversationKey.get(key) ?? [];
    if (this.loadedConversationKeys.has(key) || !this.storageDir) {
      // Fully resident or in-memory store: resident list is the full list.
      return [...resident];
    }
    // Fast path: resident window covers every in-context id → skip disk read.
    if (
      residentCoversIds(
        resident,
        this.conversations.get(key)?.in_context_message_ids ?? [],
      )
    ) {
      return [...resident];
    }
    const read = this.readConversationMessagesFromDisk(key, agentId);
    if (!read) return [...resident];
    return overlayResidentLocalMessageTail(read.messages, resident);
  }

  /**
   * The live resident message window for mutation paths (append, rollback,
   * tool settlement, approval application, streaming chunk application).
   * In-context window on disk-backed stores; appends mirror to the transcript.
   */
  private residentLocalMessagesForConversation(
    conversationId: string,
    agentId: string,
  ): LocalMessage[] {
    this.findConversation(conversationId, agentId);
    const key = this.conversationKey(conversationId, agentId);
    if (
      !this.loadedConversationKeys.has(key) &&
      !this.tailResidentConversationKeys.has(key)
    ) {
      this.loadConversationMessageTail(key, conversationId, agentId);
    }
    const messages = this.localMessagesByConversationKey.get(key) ?? [];
    this.localMessagesByConversationKey.set(key, messages);
    return messages;
  }

  /**
   * Read and normalize the full transcript from disk without changing
   * message residency; undefined when there is no transcript metadata.
   */
  private readConversationMessagesFromDisk(
    key: string,
    agentId: string,
  ):
    | {
        messages: LocalMessage[];
        transcript: LocalTranscriptRowsResult;
        metadata: LocalConversationTranscriptMetadata;
      }
    | undefined {
    const metadata = this.validateTranscriptMetadata(key);
    if (!metadata) return undefined;

    const rawRows = readJsonlFile<unknown>(metadata.messagesPath);
    const conversation = this.conversations.get(key);
    const transcript = localTranscriptRowsResult(
      rawRows,
      metadata.messageFormat,
      conversation?.in_context_message_ids ?? [],
    );
    assertNoLegacyUiMessageRows(
      transcript.messages,
      this.storageDir ?? "",
      metadata.conversationDir,
    );
    this.unreadTranscriptHeadBytesByKey.delete(key);
    const loadedMessages = repairSyntheticLocalMessageTimestamps(
      transcript.messages.map(normalizeLocalMessageForPi),
      metadata.timing,
    );
    const toolResultRepair = removeOrphanLocalToolResults(loadedMessages);
    const toolResultClip = clipOversizedLocalToolResults(
      toolResultRepair.messages,
    );
    const localMessages = toolResultClip.messages;
    if (toolResultClip.clippedToolResultIds.length > 0) {
      this.loadRepairedConversationKeys.add(key);
    } else {
      this.loadRepairedConversationKeys.delete(key);
    }
    if (conversation) {
      let repairedConversation = repairSyntheticConversationTimestamps(
        conversation,
        localMessages,
        metadata.timing,
      );
      if (toolResultRepair.removedMessageIds.length > 0) {
        const removedMessageIds = new Set(toolResultRepair.removedMessageIds);
        repairedConversation = {
          ...repairedConversation,
          in_context_message_ids:
            repairedConversation.in_context_message_ids.length > 0
              ? repairedConversation.in_context_message_ids.filter(
                  (id) => !removedMessageIds.has(id),
                )
              : localMessages.map((message) => message.id),
        };
      }
      this.conversations.set(key, repairedConversation);
      if (toolResultRepair.removedMessageIds.length > 0) {
        this.persistConversationState(conversation.id, agentId, {
          transcript: "skip",
        });
      }
    }
    for (const message of loadedMessages) {
      this.localMessageSeq = Math.max(
        this.localMessageSeq,
        numericSuffix(message.id, this.localMessageIdPrefix),
      );
    }
    return { messages: localMessages, transcript, metadata };
  }

  private markConversationFullyResident(key: string): void {
    this.tailResidentConversationKeys.delete(key);
    this.residentTailStartIndexByConversationKey.delete(key);
    this.loadedConversationKeys.add(key);
  }

  private markNewConversationResident(key: string): void {
    this.localMessagesByConversationKey.set(key, []);
    if (this.storageDir) {
      this.loadedConversationKeys.delete(key);
      this.tailResidentConversationKeys.add(key);
      this.residentTailStartIndexByConversationKey.set(key, 0);
      return;
    }
    this.markConversationFullyResident(key);
  }

  /**
   * Full load: the entire parsed transcript becomes resident (legacy format,
   * synthetic timestamp repair, in-memory stores).
   */
  private loadConversationMessages(
    key: string,
    conversationId: string,
    agentId: string,
  ): void {
    const read = this.readConversationMessagesFromDisk(key, agentId);
    if (!read) {
      this.localMessagesByConversationKey.set(
        key,
        this.localMessagesByConversationKey.get(key) ?? [],
      );
      this.markConversationFullyResident(key);
      return;
    }
    this.localMessagesByConversationKey.set(key, read.messages);
    this.markConversationFullyResident(key);
    this.resetPersistedSessionState(
      key,
      read.metadata.messageFormat,
      read.transcript,
    );
    this.projectLocalMessages(read.messages, agentId, conversationId);
  }

  /**
   * Tail load: the transcript suffix holding every in-context message becomes
   * the resident window; append dedup, parent chaining, and rollback
   * detection only consult it.
   */
  private loadConversationMessageTail(
    key: string,
    conversationId: string,
    agentId: string,
  ): void {
    const metadata = this.validateTranscriptMetadata(key);
    if (
      !metadata ||
      metadata.messageFormat !== LOCAL_TRANSCRIPT_MESSAGE_FORMAT ||
      metadata.requiresFullTimestampRepair
    ) {
      this.loadConversationMessages(key, conversationId, agentId);
      return;
    }
    const conversation = this.conversations.get(key);
    const {
      transcript,
      messages: tailMessages,
      headBytes,
      liveInContextIds,
    } = readLocalTranscriptTailWindow(
      metadata.messagesPath,
      metadata.messageFormat,
      conversation?.in_context_message_ids ?? [],
      this.residentMessageTailLimit,
      this.storageDir ?? "",
      metadata.conversationDir,
    );
    // The resident window must match a full load's repaired view, since it
    // wins over the disk read for its ids.
    const toolResultClip = clipOversizedLocalToolResults(tailMessages);
    const messages = toolResultClip.messages;
    if (toolResultClip.clippedToolResultIds.length > 0) {
      this.loadRepairedConversationKeys.add(key);
    }
    this.localMessagesByConversationKey.set(key, messages);
    // Ids with no row (killed mid-stream) or dropped as orphans leave context.
    if (conversation) conversation.in_context_message_ids = liveInContextIds;
    // Track the unparsed head for one-time pre-append validation (F13).
    if (headBytes > 0) this.unreadTranscriptHeadBytesByKey.set(key, headBytes);
    else this.unreadTranscriptHeadBytesByKey.delete(key);
    this.loadedConversationKeys.delete(key);
    this.tailResidentConversationKeys.add(key);
    this.residentTailStartIndexByConversationKey.set(
      key,
      transcript.sourceStartIndex,
    );
    this.resetPersistedSessionState(
      key,
      metadata.messageFormat,
      restrictLocalTranscriptToResidentMessages(transcript, messages),
    );
    for (const message of messages) {
      this.localMessageSeq = Math.max(
        this.localMessageSeq,
        numericSuffix(message.id, this.localMessageIdPrefix),
      );
    }
    this.projectLocalMessages(messages, agentId, conversationId, {
      sourceStartIndex: transcript.sourceStartIndex,
    });
  }

  /**
   * Replace the resident window after a wholesale in-memory rewrite
   * (compaction); the caller's persist appends the rewrite entry to disk.
   */
  private setResidentConversationMessages(
    key: string,
    messages: LocalMessage[],
  ): void {
    const prior = this.localMessagesByConversationKey.get(key);
    this.evictResidentHeadMessages(key, messagesMissingFrom(prior, messages));
    this.localMessagesByConversationKey.set(key, messages);
    if (!this.storageDir) {
      this.markConversationFullyResident(key);
      return;
    }
    this.loadedConversationKeys.delete(key);
    this.tailResidentConversationKeys.add(key);
    this.residentTailStartIndexByConversationKey.set(key, 0);
    this.trimResidentConversationTail(key);
  }

  /** Drop a fully resident conversation back to its bounded tail window. */
  private demoteConversationToResidentTail(key: string): void {
    if (!this.storageDir) return;
    if (!this.loadedConversationKeys.delete(key)) return;
    this.tailResidentConversationKeys.add(key);
    this.residentTailStartIndexByConversationKey.set(key, 0);
    this.trimResidentConversationTail(key);
  }

  /** Evict out-of-context messages (still on disk) beyond the resident floor. */
  private trimResidentConversationTail(key: string): void {
    if (!this.storageDir) return;
    if (!this.tailResidentConversationKeys.has(key)) return;
    const messages = this.localMessagesByConversationKey.get(key);
    if (!messages || messages.length <= this.residentMessageTailLimit) return;
    const evicted = spliceOutOfContextMessages(
      messages,
      this.conversations.get(key)?.in_context_message_ids ?? [],
      this.residentMessageTailLimit,
    );
    this.evictResidentHeadMessages(key, evicted);
  }

  private evictResidentHeadMessages(
    key: string,
    evicted: readonly LocalMessage[],
  ): void {
    if (evicted.length === 0) return;
    const conversation = this.conversations.get(key);
    const persistedById =
      this.persistedMessageByMessageIdByConversationKey.get(key);
    for (const message of evicted) {
      persistedById?.delete(message.id);
      if (!conversation) continue;
      // Lookup keys derive only from the message id, so re-projecting with an
      // empty fallback date yields the exact keys to drop (retrieveMessage
      // falls back to disk scans for evicted ids).
      const projected = projectLocalMessageToStoredMessages(
        message,
        conversation.agent_id,
        conversation.id,
        "",
      );
      for (const [lookupKey] of projectedMessageLookupKeys(
        message,
        projected,
      )) {
        this.messagesById.delete(lookupKey);
      }
    }
  }

  private pushLocalMessage(
    conversationId: string,
    agentId: string,
    message: LocalMessage,
  ): void {
    const messages = this.residentLocalMessagesForConversation(
      conversationId,
      agentId,
    );
    const key = this.conversationKey(conversationId, agentId);
    // Post-load, pre-mutation: a corrupt head throws, nothing written.
    this.validateUnreadTranscriptHeadOnce(key);
    messages.push(message);
    this.trimResidentConversationTail(key);
    this.touchConversationForLocalMessage(conversationId, agentId, message);
    this.persistConversationState(conversationId, agentId, {
      transcript: "append",
      message,
    });
  }

  // Validate the unparsed head pre-append; a throw retains it for retries.
  private validateUnreadTranscriptHeadOnce(key: string): void {
    const headBytes = this.unreadTranscriptHeadBytesByKey.get(key);
    if (headBytes === undefined) return;
    const metadata = this.transcriptMetadataByConversationKey.get(key);
    if (metadata) {
      validateUnreadTranscriptHead(
        metadata.messagesPath,
        headBytes,
        this.storageDir ?? "",
        metadata.conversationDir,
        this.conversations.get(key)?.in_context_message_ids ?? [],
      );
    }
    this.unreadTranscriptHeadBytesByKey.delete(key);
  }

  private persistPendingAssistantMessage(
    conversationId: string,
    agentId: string,
  ): void {
    const messages = this.residentLocalMessagesForConversation(
      conversationId,
      agentId,
    );
    const last = messages.at(-1);
    if (last?.role !== "assistant") {
      this.persistConversationState(conversationId, agentId, {
        transcript: "skip",
      });
      return;
    }
    // Mark settled regardless of storageDir so rollback works in-memory.
    this.settledLocalMessageIds.add(last.id);
    this.persistConversationState(conversationId, agentId, {
      transcript: "append",
      message: last,
    });
  }

  private touchConversationForLocalMessage(
    conversationId: string,
    agentId: string,
    message: LocalMessage,
  ): void {
    const key = this.conversationKey(conversationId, agentId);
    const conversation = this.conversations.get(key);
    if (!conversation) return;
    if (!conversation.in_context_message_ids.includes(message.id)) {
      conversation.in_context_message_ids = [
        ...conversation.in_context_message_ids,
        message.id,
      ];
    }
    const date = localMessageDate(message, currentIsoTimestamp());
    conversation.last_message_at = date;
    conversation.updated_at = date;
    this.conversations.set(key, conversation);
  }

  private cloneLocalMessageForConversation(
    message: LocalMessage,
    conversationId: string,
    agentId: string,
  ): LocalMessage {
    const cloned = cloneLocalMessage(message);
    const date = cloned.metadata?.created_at ?? this.nextLocalMessageDate();
    return {
      ...cloned,
      id: this.nextLocalMessageId(),
      metadata: {
        ...cloned.metadata,
        created_at: date,
        updated_at: cloned.metadata?.updated_at ?? date,
        agent_id: agentId,
        conversation_id: conversationId,
      },
    };
  }

  private localContentFromInputContent(
    content: unknown,
  ): LocalUserMessage["content"] {
    if (typeof content === "string") return [{ type: "text", text: content }];
    if (!Array.isArray(content)) return textContent(textFromContent(content));
    const parts: LocalContentPart[] = [];
    for (const part of content) {
      if (!isRecord(part)) continue;
      if (part.type === "text" && typeof part.text === "string") {
        parts.push({ type: "text", text: part.text });
        continue;
      }
      const imagePart = localImageContentFromLegacyImage(part);
      if (imagePart) {
        parts.push(imagePart);
      }
    }
    return parts.length > 0 ? parts : textContent(textFromContent(content));
  }

  private nextLocalMessageId(): string {
    this.localMessageSeq += 1;
    return `${this.localMessageIdPrefix}${this.localMessageSeq}`;
  }

  private nextLocalMessageDate(): string {
    return currentIsoTimestamp();
  }

  private currentLocalMessageDate(): string {
    return currentIsoTimestamp();
  }

  private setTranscriptMetadata(
    key: string,
    metadata: LocalConversationTranscriptMetadata,
  ): LocalConversationTranscriptMetadata {
    this.transcriptMetadataByConversationKey.set(key, metadata);
    return metadata;
  }

  private transcriptMetadataRecord(
    key: string,
    conversationDir: string,
    options: { requiresFullTimestampRepair?: boolean } = {},
  ): LocalConversationTranscriptMetadata {
    const existing = this.transcriptMetadataByConversationKey.get(key);
    if (existing) return existing;
    return this.setTranscriptMetadata(key, {
      conversationDir,
      messagesPath: transcriptMessagesPath(conversationDir),
      messageFormat: LOCAL_TRANSCRIPT_MESSAGE_FORMAT,
      manifestValidated: false,
      timing: transcriptTimingForConversationDir(conversationDir),
      requiresFullTimestampRepair: options.requiresFullTimestampRepair === true,
    });
  }

  private validateTranscriptMetadata(
    key: string,
  ): LocalConversationTranscriptMetadata | undefined {
    const metadata = this.transcriptMetadataByConversationKey.get(key);
    if (!metadata) return undefined;
    if (metadata.manifestValidated) return metadata;

    const manifest = validateLocalTranscriptManifest(
      metadata.conversationDir,
      this.storageDir ?? "",
    );
    return this.setTranscriptMetadata(key, {
      ...metadata,
      messageFormat:
        manifest?.message_format ?? LOCAL_TRANSCRIPT_MESSAGE_FORMAT,
      manifestValidated: true,
      timing: transcriptTimingForConversationDir(
        metadata.conversationDir,
        manifest,
      ),
    });
  }

  private conversationsDir(): string | undefined {
    return this.storageDir ? join(this.storageDir, "conversations") : undefined;
  }

  private conversationDirForKey(key: string): string | undefined {
    const conversationsDir = this.conversationsDir();
    return conversationsDir
      ? join(conversationsDir, encodePathSegment(key))
      : undefined;
  }

  private updateConversationSequences(conversation: StoredConversation): void {
    this.conversationSeq = Math.max(
      this.conversationSeq,
      numericSuffix(conversation.id, this.conversationIdPrefix),
    );

    for (const messageId of conversation.in_context_message_ids ?? []) {
      this.localMessageSeq = Math.max(
        this.localMessageSeq,
        numericSuffix(messageId, this.localMessageIdPrefix),
      );
    }
  }

  private cacheConversationRecord(
    conversationDir: string,
    input: StoredConversation,
    options: { forceRefresh?: boolean; recordJson: string },
  ): StoredConversation {
    const key = this.conversationKey(input.id, input.agent_id);
    const existing = this.conversations.get(key);
    if (existing && options.forceRefresh !== true) return existing;

    const normalizedInput = this.withConversationModelDefaults(
      normalizeStoredLocalModelRecord(input),
    );
    const timing = transcriptTimingForConversationDir(conversationDir);
    const requiresFullTimestampRepair =
      isSyntheticLocalTimestamp(normalizedInput.created_at) ||
      isSyntheticLocalTimestamp(normalizedInput.updated_at) ||
      isSyntheticLocalTimestamp(normalizedInput.last_message_at);
    const conversation = requiresFullTimestampRepair
      ? normalizedInput
      : repairSyntheticConversationTimestamps(normalizedInput, [], timing);
    let compiledSystemPrompt: LocalCompiledSystemPrompt | undefined;
    try {
      compiledSystemPrompt = readJsonFile<LocalCompiledSystemPrompt>(
        join(conversationDir, "system-prompt.json"),
      );
    } catch {
      compiledSystemPrompt = undefined;
    }

    this.conversations.set(key, conversation);
    this.conversationRecordJsonByKey.set(key, options.recordJson);
    this.transcriptMetadataRecord(key, conversationDir, {
      requiresFullTimestampRepair,
    });
    if (compiledSystemPrompt?.content) {
      this.compiledSystemPromptByConversationKey.set(key, compiledSystemPrompt);
    }
    this.updateConversationSequences(conversation);
    return conversation;
  }

  private loadConversationRecordFromDir(
    conversationDir: string,
  ): StoredConversation | undefined {
    try {
      const recordJson = readFileSync(
        join(conversationDir, "conversation.json"),
        "utf8",
      );
      const conversation = parsePersistedLocalConversation(recordJson, (id) =>
        this.executionAgentIdForConversation(id),
      );
      if (!conversation) return undefined;
      return this.cacheConversationRecord(conversationDir, conversation, {
        recordJson,
      });
    } catch {
      return undefined;
    }
  }

  private refreshConversationRecordFromStorage(
    key: string,
  ): StoredConversation | undefined {
    const existing = this.conversations.get(key);
    const metadata = this.transcriptMetadataByConversationKey.get(key);
    const conversationDir =
      metadata?.conversationDir ?? this.conversationDirForKey(key);
    if (!conversationDir) return existing;

    try {
      // Filesystem timestamps (and byte lengths) can match across compactions.
      // Compare the record itself; unchanged records retain in-flight state.
      const recordJson = readFileSync(
        join(conversationDir, "conversation.json"),
        "utf8",
      );
      const cachedJson = this.conversationRecordJsonByKey.get(key);
      if (existing && cachedJson === recordJson) return existing;
      const conversation = parsePersistedLocalConversation(recordJson, (id) =>
        this.executionAgentIdForConversation(id),
      );
      if (!conversation) return existing;
      const loadedKey = this.conversationKey(
        conversation.id,
        conversation.agent_id,
      );
      if (loadedKey !== key) return existing;
      // Own writes cache their serialized record, so only external changes
      // invalidate the resident transcript window.
      if (existing && cachedJson !== undefined) {
        this.evictResidentHeadMessages(
          key,
          this.localMessagesByConversationKey.get(key) ?? [],
        );
        this.localMessagesByConversationKey.delete(key);
        this.loadedConversationKeys.delete(key);
        this.tailResidentConversationKeys.delete(key);
        this.residentTailStartIndexByConversationKey.delete(key);
        this.unreadTranscriptHeadBytesByKey.delete(key);
      }
      return this.cacheConversationRecord(conversationDir, conversation, {
        forceRefresh: true,
        recordJson,
      });
    } catch {
      return existing;
    }
  }

  private loadConversationRecordsFromStorage(): void {
    if (this.conversationRecordsScanned) return;
    this.conversationRecordsScanned = true;
    const conversationsDir = this.conversationsDir();
    if (!conversationsDir || !existsSync(conversationsDir)) return;

    let entries: string[];
    try {
      entries = readdirSync(conversationsDir);
    } catch {
      return;
    }

    for (const entry of entries) {
      const conversationDir = join(conversationsDir, entry);
      try {
        if (!statSync(conversationDir).isDirectory()) continue;
      } catch {
        continue;
      }
      this.loadConversationRecordFromDir(conversationDir);
    }
  }

  private refreshLoadedConversationRecordsFromStorage(): void {
    for (const key of [...this.conversations.keys()]) {
      this.refreshConversationRecordFromStorage(key);
    }
  }

  private loadFromStorage(): void {
    if (!this.storageDir || !existsSync(this.storageDir)) return;

    const agentsDir = join(this.storageDir, "agents");
    if (existsSync(agentsDir)) {
      for (const file of readdirSync(agentsDir)) {
        if (!file.endsWith(".json") || file.startsWith("._")) continue;
        const filePath = join(agentsDir, file);
        const mtimeMs = statSync(filePath).mtimeMs;
        const raw = readJsonFile<unknown>(filePath);
        const agent = normalizeAgentRecord(raw, this.defaultAgentModel);
        if (agent?.id) {
          this.agents.set(agent.id, agent);
          this.recordAgentRecordMtime(agent.id, mtimeMs);
          if (shouldPersistSubagentHiddenBackfill(raw, agent)) {
            this.persistAgent(agent.id);
          }
        }
      }
    }
  }

  private persistAgent(agentId: string): void {
    if (!this.storageDir) return;
    const agent = this.agents.get(agentId);
    if (!agent) return;
    const agentsDir = join(this.storageDir, "agents");
    mkdirSync(agentsDir, { recursive: true });
    writeFileSync(
      join(agentsDir, `${encodePathSegment(agentId)}.json`),
      `${JSON.stringify(agent, null, 2)}\n`,
    );
    this.recordAgentRecordMtime(agentId);
  }

  private agentRecordFileMtimeMs(agentId: string): number | undefined {
    if (!this.storageDir) return undefined;
    try {
      return statSync(
        join(this.storageDir, "agents", `${encodePathSegment(agentId)}.json`),
      ).mtimeMs;
    } catch {
      return undefined;
    }
  }

  private recordAgentRecordMtime(agentId: string, mtimeMs?: number): void {
    const recordedMtimeMs = mtimeMs ?? this.agentRecordFileMtimeMs(agentId);
    if (recordedMtimeMs === undefined) {
      this.agentRecordMtimeMsById.delete(agentId);
      return;
    }
    this.agentRecordMtimeMsById.set(agentId, recordedMtimeMs);
  }

  private refreshAgentRecordFromStorage(
    agentId: string,
  ): LocalAgentRecord | undefined {
    const existing = this.agents.get(agentId);
    if (!this.storageDir || !existing) return existing;
    const mtimeMs = this.agentRecordFileMtimeMs(agentId);
    if (mtimeMs === undefined) return existing;
    if (this.agentRecordMtimeMsById.get(agentId) === mtimeMs) return existing;

    try {
      const raw = readJsonFile<unknown>(
        join(this.storageDir, "agents", `${encodePathSegment(agentId)}.json`),
      );
      const agent = normalizeAgentRecord(raw, this.defaultAgentModel);
      if (!agent || agent.id !== agentId) return existing;
      this.agents.set(agentId, agent);
      this.recordAgentRecordMtime(agentId, mtimeMs);
      return agent;
    } catch {
      return existing;
    }
  }

  private refreshLoadedAgentRecordsFromStorage(): void {
    for (const agentId of this.agents.keys()) {
      this.refreshAgentRecordFromStorage(agentId);
    }
  }

  private projectAgent(record: LocalAgentRecord): AgentState {
    const defaultConversation = this.findConversation("default", record.id);
    const messageIds = defaultConversation?.in_context_message_ids ?? [];
    const inContextMessageIds =
      defaultConversation?.in_context_message_ids ?? messageIds;
    const lastRunCompletion =
      defaultConversation?.last_message_at ??
      defaultConversation?.updated_at ??
      null;
    return projectLocalAgentState(
      this.projectableAgentRecord(record),
      messageIds,
      inContextMessageIds,
      lastRunCompletion,
    );
  }

  private persistConversationState(
    conversationId: string,
    agentId: string,
    options: LocalTranscriptPersistOptions = {},
  ): void {
    if (!this.storageDir) return;
    const key = this.conversationKey(conversationId, agentId);
    const conversation = this.conversations.get(key);
    if (!conversation) return;

    const conversationDir = join(
      this.storageDir,
      "conversations",
      encodePathSegment(key),
    );
    mkdirSync(conversationDir, { recursive: true });
    const persistedConversation = conversation.agent_free
      ? { ...conversation, agent_id: null }
      : conversation;
    const recordJson = `${JSON.stringify(persistedConversation, null, 2)}\n`;
    writeFileSync(join(conversationDir, "conversation.json"), recordJson);
    this.conversationRecordJsonByKey.set(key, recordJson);
    const messagesPath = transcriptMessagesPath(conversationDir);
    let metadata = this.transcriptMetadataRecord(key, conversationDir);
    const manifestPath = transcriptManifestPath(conversationDir);
    if (!existsSync(manifestPath) && !hasNonEmptyJsonl(messagesPath)) {
      const manifest = createLocalTranscriptManifest();
      writeLocalTranscriptManifest(conversationDir, manifest);
      metadata = this.setTranscriptMetadata(key, {
        ...metadata,
        messageFormat: LOCAL_TRANSCRIPT_MESSAGE_FORMAT,
        manifestValidated: true,
        timing: transcriptTimingForConversationDir(conversationDir, manifest),
      });
    } else {
      metadata = this.validateTranscriptMetadata(key) ?? metadata;
    }
    const messageFormat = metadata.messageFormat;
    this.persistConversationTranscript(
      key,
      conversation,
      conversationDir,
      messagesPath,
      messageFormat,
      options,
    );
    this.persistCompiledSystemPrompt(conversationId, agentId);
  }

  private persistConversationTranscript(
    key: string,
    conversation: StoredConversation,
    conversationDir: string,
    messagesPath: string,
    messageFormat: LocalTranscriptMessageFormat,
    options: LocalTranscriptPersistOptions,
  ): void {
    if (options.transcript === "skip") return;
    if (
      options.transcript === undefined &&
      this.loadRepairedConversationKeys.has(key) &&
      existsSync(messagesPath)
    ) {
      return;
    }
    const messages = this.localMessagesByConversationKey.get(key) ?? [];
    let activeMessageFormat = messageFormat;
    if (messageFormat === LOCAL_TRANSCRIPT_LEGACY_MESSAGE_FORMAT) {
      const upgradeMessages = options.compaction?.previousMessages ?? messages;
      if (upgradeMessages.length === 0) return;
      this.rewriteConversationSessionTranscript(
        key,
        conversation,
        messagesPath,
        upgradeMessages,
      );
      const manifest = createLocalTranscriptManifest({
        migratedFrom: "versioned-pi-ai-message-jsonl",
      });
      writeLocalTranscriptManifest(conversationDir, manifest);
      const metadata = this.transcriptMetadataByConversationKey.get(key);
      if (metadata) {
        this.transcriptMetadataByConversationKey.set(key, {
          ...metadata,
          messageFormat: LOCAL_TRANSCRIPT_MESSAGE_FORMAT,
          manifestValidated: true,
          timing: transcriptTimingForConversationDir(conversationDir, manifest),
        });
      }
      activeMessageFormat = LOCAL_TRANSCRIPT_MESSAGE_FORMAT;
    }

    if (activeMessageFormat !== LOCAL_TRANSCRIPT_MESSAGE_FORMAT) return;

    if (options.transcript === "append" && options.message) {
      this.appendConversationSessionMessageEntry(
        key,
        conversation,
        messagesPath,
        options.message,
      );
      return;
    }

    if (options.transcript === "append-compaction" && options.compaction) {
      this.appendConversationSessionCompactionEntry(
        key,
        conversation,
        messagesPath,
        options.compaction,
      );
      return;
    }

    if (
      options.transcript === "rewrite" ||
      this.loadedConversationKeys.has(key) ||
      // Never rewrite the transcript from a bounded resident tail — it would
      // truncate history to the window.
      (!existsSync(messagesPath) && !this.tailResidentConversationKeys.has(key))
    ) {
      if (messages.length === 0) return;
      this.rewriteConversationSessionTranscript(
        key,
        conversation,
        messagesPath,
        messages,
      );
      this.loadRepairedConversationKeys.delete(key);
    }
  }

  private rewriteConversationSessionTranscript(
    key: string,
    conversation: StoredConversation,
    messagesPath: string,
    messages: readonly LocalMessage[],
  ): void {
    if (messages.length === 0) return;
    const entries = localTranscriptSessionEntries(conversation, messages);
    writeFileSync(messagesPath, jsonl(entries));
    this.resetPersistedSessionStateFromEntries(key, entries);
  }

  private appendConversationSessionMessageEntry(
    key: string,
    conversation: StoredConversation,
    messagesPath: string,
    message: LocalMessage,
  ): void {
    const entryIdByMessageId = this.sessionEntryIdsByMessageId(key);
    if (entryIdByMessageId.has(message.id)) {
      const persistedMessage = this.persistedMessagesByMessageId(key).get(
        message.id,
      );
      if (
        persistedMessage &&
        localMessagesHaveSameSnapshot(persistedMessage, message)
      ) {
        return;
      }
    }

    this.ensureConversationTranscriptHeader(conversation, messagesPath);
    const parentId = this.lastSessionEntryIdByConversationKey.get(key) ?? null;
    const entry: LocalTranscriptSessionMessageEntry = {
      type: "message",
      id: this.nextSessionEntryId(key),
      parentId,
      timestamp: localMessageDate(message, currentIsoTimestamp()),
      message,
    };
    this.appendConversationSessionEntry(key, messagesPath, entry);
  }

  private appendConversationSessionCompactionEntry(
    key: string,
    conversation: StoredConversation,
    messagesPath: string,
    compaction: NonNullable<LocalTranscriptPersistOptions["compaction"]>,
  ): void {
    const entryIdByMessageId = this.sessionEntryIdsByMessageId(key);
    if (entryIdByMessageId.has(compaction.summaryMessage.id)) return;

    this.ensureConversationTranscriptHeader(conversation, messagesPath);
    const parentId = this.lastSessionEntryIdByConversationKey.get(key) ?? null;
    const entry: LocalTranscriptCompactionEntry = {
      type: "compaction",
      id: this.nextSessionEntryId(key),
      parentId,
      timestamp: localMessageDate(
        compaction.summaryMessage,
        currentIsoTimestamp(),
      ),
      summary: compaction.summary,
      firstKeptEntryId: compaction.firstKeptMessageId
        ? (entryIdByMessageId.get(compaction.firstKeptMessageId) ?? null)
        : null,
      tokensBefore: compaction.stats?.context_tokens_before ?? 0,
      message: compaction.summaryMessage,
      ...(compaction.stats ? { details: { stats: compaction.stats } } : {}),
    };
    this.appendConversationSessionEntry(key, messagesPath, entry);
  }

  private appendConversationSessionEntry(
    key: string,
    messagesPath: string,
    entry: LocalTranscriptAppendEntry,
  ): void {
    this.validateUnreadTranscriptHeadOnce(key);
    appendFileSync(messagesPath, `${JSON.stringify(entry)}\n`);
    this.sessionEntryIds(key).add(entry.id);
    this.sessionEntryIdsByMessageId(key).set(entry.message.id, entry.id);
    this.persistedMessagesByMessageId(key).set(
      entry.message.id,
      cloneLocalMessage(entry.message),
    );
    this.lastSessionEntryIdByConversationKey.set(key, entry.id);
  }

  private ensureConversationTranscriptHeader(
    conversation: StoredConversation,
    messagesPath: string,
  ): void {
    if (existsSync(messagesPath) && statSync(messagesPath).size > 0) return;
    writeFileSync(
      messagesPath,
      `${JSON.stringify(createLocalTranscriptSessionHeader(conversation))}\n`,
    );
  }

  private resetPersistedSessionState(
    key: string,
    messageFormat: LocalTranscriptMessageFormat,
    transcript: LocalTranscriptRowsResult,
  ): void {
    if (messageFormat !== LOCAL_TRANSCRIPT_MESSAGE_FORMAT) return;
    this.sessionEntryIdsByConversationKey.set(key, transcript.entryIds);
    this.sessionEntryIdByMessageIdByConversationKey.set(
      key,
      transcript.entryIdByMessageId,
    );
    this.persistedMessageByMessageIdByConversationKey.set(
      key,
      new Map(
        Array.from(transcript.messageById, ([messageId, message]) => [
          messageId,
          cloneLocalMessage(message),
        ]),
      ),
    );
    this.lastSessionEntryIdByConversationKey.set(key, transcript.lastEntryId);
  }

  private resetPersistedSessionStateFromEntries(
    key: string,
    entries: readonly LocalTranscriptSessionEntry[],
  ): void {
    this.resetPersistedSessionState(
      key,
      LOCAL_TRANSCRIPT_MESSAGE_FORMAT,
      localTranscriptRowsResult(entries, LOCAL_TRANSCRIPT_MESSAGE_FORMAT),
    );
  }

  private sessionEntryIds(key: string): Set<string> {
    let entryIds = this.sessionEntryIdsByConversationKey.get(key);
    if (!entryIds) {
      entryIds = new Set<string>();
      this.sessionEntryIdsByConversationKey.set(key, entryIds);
    }
    return entryIds;
  }

  private sessionEntryIdsByMessageId(key: string): Map<string, string> {
    let entryIds = this.sessionEntryIdByMessageIdByConversationKey.get(key);
    if (!entryIds) {
      entryIds = new Map<string, string>();
      this.sessionEntryIdByMessageIdByConversationKey.set(key, entryIds);
    }
    return entryIds;
  }

  private persistedMessagesByMessageId(key: string): Map<string, LocalMessage> {
    let messages = this.persistedMessageByMessageIdByConversationKey.get(key);
    if (!messages) {
      messages = new Map<string, LocalMessage>();
      this.persistedMessageByMessageIdByConversationKey.set(key, messages);
    }
    return messages;
  }

  private nextSessionEntryId(key: string): string {
    const entryIds = this.sessionEntryIds(key);
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const id = randomUUID().slice(0, 8);
      if (!entryIds.has(id)) return id;
    }
    return randomUUID();
  }

  private persistCompiledSystemPrompt(
    conversationId: string,
    agentId: string,
  ): void {
    if (!this.storageDir) return;
    const key = this.conversationKey(conversationId, agentId);
    const prompt = this.compiledSystemPromptByConversationKey.get(key);
    if (!prompt) return;
    const conversationDir = join(
      this.storageDir,
      "conversations",
      encodePathSegment(key),
    );
    mkdirSync(conversationDir, { recursive: true });
    writeFileSync(
      join(conversationDir, "system-prompt.json"),
      `${JSON.stringify(prompt, null, 2)}\n`,
    );
  }

  private ensureConversation(
    conversationId: string,
    agentId?: string,
  ): StoredConversation {
    const resolvedAgentId = agentId ?? this.defaultAgentId;
    const existing = this.findConversation(conversationId, resolvedAgentId);
    if (existing) return existing;

    const key = this.conversationKey(conversationId, resolvedAgentId);

    const shouldAdvanceSequence = conversationId !== "default";
    if (shouldAdvanceSequence) {
      this.conversationSeq += 1;
    }
    const conversation = createLocalConversationRecord(
      conversationId,
      resolvedAgentId,
    );
    this.conversations.set(key, conversation);
    this.markNewConversationResident(key);
    this.persistConversationState(conversation.id, resolvedAgentId);
    return conversation;
  }

  private nextConversationId(agentId?: string): string {
    const resolvedAgentId = agentId ?? this.defaultAgentId;
    for (;;) {
      this.conversationSeq += 1;
      const conversationId = `${this.conversationIdPrefix}${this.conversationSeq}`;
      const key = this.conversationKey(conversationId, resolvedAgentId);
      if (this.conversations.has(key)) continue;
      const conversationDir = this.conversationDirForKey(key);
      if (conversationDir && existsSync(conversationDir)) continue;
      return conversationId;
    }
  }

  private findConversation(
    conversationId: string,
    agentId?: string,
  ): StoredConversation | undefined {
    if (agentId) {
      const key = this.conversationKey(conversationId, agentId);
      const direct = this.refreshConversationRecordFromStorage(key);
      if (direct || conversationId === "default") return direct;
      this.loadConversationRecordsFromStorage();
      return this.refreshConversationRecordFromStorage(key);
    }
    if (conversationId === "default") {
      const key = this.conversationKey(conversationId, this.defaultAgentId);
      return this.refreshConversationRecordFromStorage(key);
    }
    const key = this.conversationKey(conversationId, this.defaultAgentId);
    const direct = this.refreshConversationRecordFromStorage(key);
    if (direct) return direct;
    this.loadConversationRecordsFromStorage();
    return this.refreshConversationRecordFromStorage(key);
  }

  private toolSettlementTargets(
    conversationIdOrAgentId: string,
    agentId?: string,
  ): Array<{ conversationId: string; agentId: string }> {
    if (agentId) {
      const conversation = this.findConversation(
        conversationIdOrAgentId,
        agentId,
      );
      return conversation
        ? [{ conversationId: conversation.id, agentId: conversation.agent_id }]
        : [];
    }

    const conversation = this.findConversation(conversationIdOrAgentId);
    if (conversation) {
      return [
        { conversationId: conversation.id, agentId: conversation.agent_id },
      ];
    }

    if (this.agents.has(conversationIdOrAgentId)) {
      const defaultConversation = this.ensureConversation(
        "default",
        conversationIdOrAgentId,
      );
      return [
        {
          conversationId: defaultConversation.id,
          agentId: defaultConversation.agent_id,
        },
      ];
    }

    return [];
  }

  private executionAgentIdForConversation(conversationId: string): string {
    return `agent-free:${conversationId}`;
  }

  private agentIdForConversation(conversationId: string): string {
    if (conversationId === "default") return this.defaultAgentId;
    const conversation = this.findConversation(conversationId);
    if (!conversation) return this.defaultAgentId;
    return conversation.agent_free
      ? this.executionAgentIdForConversation(conversationId)
      : conversation.agent_id;
  }

  private conversationKey(conversationId: string, agentId: string): string {
    return conversationId === "default"
      ? `default:${agentId}`
      : `conversation:${conversationId}`;
  }
}
