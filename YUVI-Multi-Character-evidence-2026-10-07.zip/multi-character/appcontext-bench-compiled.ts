// Construction-only resource benchmark: real AppContext, offline mocks and in-memory stores.
// No durable A8/A9/production gate is claimed; model serving is excluded.
import { createAppContext } from '../YUVI-multi-character/apps/server/dist/context.js';
import { loadServerConfig } from '../YUVI-multi-character/apps/server/dist/config.js';
import Fastify from '../YUVI-multi-character/apps/server/node_modules/fastify/fastify.js';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const root=mkdtempSync(join(tmpdir(),'yuvi-instance-bench-'));
delete process.env.DATABASE_URL;
Object.assign(process.env,{NODE_ENV:'test',RUNTIME_MODE:'development',YUVI_RUNTIME_ENV_DIR:root,YUVI_RUNTIME_DATA_DIR:join(root,'data'),MEMORY_REPOSITORY:'in-memory',MEMORY_BACKEND:'legacy',MEMORY_EXTRACTOR:'rule-based',PROVIDER_ALLOW_MOCKS:'true',EVENT_BUS:'in-memory',MEMORY_MAINTENANCE_ENABLED:'false',MEMORY_MAINTENANCE_RUN_ON_STARTUP:'false',MEMORY_INGESTION_COORDINATOR_ENABLED:'false',YUVI_DEV_SUPERVISOR:'false',DEFAULT_CHAT_PROVIDER:'mock',DEFAULT_REASONING_PROVIDER:'mock',DEFAULT_TTS_PROVIDER:'mock',DEFAULT_STT_PROVIDER:'mock',DEFAULT_VISION_PROVIDER:'mock',DEFAULT_EMBEDDING_PROVIDER:'mock'});
const n=Number(process.argv[2]??1);global.gc?.();const before=process.memoryUsage();const app=Fastify({logger:false});const config=loadServerConfig();
const start=performance.now();const contexts=[];
for(let i=0;i<n;i++)contexts.push(await createAppContext(app.log,config));
const constructionMs=performance.now()-start;global.gc?.();const after=process.memoryUsage();
console.log(JSON.stringify({mode:'AppContext-construction',n,constructionMs,before,after,heapDelta:after.heapUsed-before.heapUsed,rssDelta:after.rss-before.rss}));
const holdMs=Number(process.argv[3]??0);if(holdMs>0)await new Promise(resolve=>setTimeout(resolve,holdMs));
for(const c of contexts){c.runtime.stopProactiveScheduler();await c.runtime.sealAndDrainMemoryWrites();await c.memoryIngestionCoordinator.shutdown({graceMs:0});await c.conversationRepository.close?.();await c.finalizedIngestionRepository.close?.();await c.memoryRepository.close?.();await c.closeDatabasePool();}
await app.close();rmSync(root,{recursive:true,force:true});
