// Research-only probe of the pinned, unmodified YUVI Core. No network or QQ calls.
import { RuntimeOrchestrator } from '../YUVI-multi-character/packages/core/src/index.ts';
import { InMemoryEventBus } from '../YUVI-multi-character/packages/event-bus/src/index.ts';
import { InMemoryConversationRepository } from '../YUVI-multi-character/packages/memory/src/conversation-repository.ts';
import { PromptBuilder } from '../YUVI-multi-character/packages/prompt-builder/src/index.ts';
import { createProviderRegistryFromEnv, withProviderWorkContext, currentProviderWorkContext } from '../YUVI-multi-character/packages/providers/src/index.ts';
import { createP8Projection } from '../YUVI-multi-character/packages/p8/src/index.ts';
import { writeFileSync } from 'node:fs';

const memory = {
  retrieveRelevantMemories: async () => [],
  retrieveRelevantMemoriesWithMetadata: async () => ({ memories: [], selectedMemories: [], rawMemories: [] }),
  scoreImportance: () => 0,
  extractCandidates: async () => [],
  rememberInteraction: async () => null
};
const providers = createProviderRegistryFromEnv({ NODE_ENV:'test', PROVIDER_ALLOW_MOCKS:'true', DEFAULT_CHAT_PROVIDER:'mock', DEFAULT_REASONING_PROVIDER:'mock', DEFAULT_STT_PROVIDER:'mock', DEFAULT_TTS_PROVIDER:'mock', DEFAULT_VISION_PROVIDER:'mock', DEFAULT_EMBEDDING_PROVIDER:'mock' });

function build(label: string, conversation = new InMemoryConversationRepository()) {
  const captured: any[] = [], lookups: any[] = [];
  const character = {
    async generate(input: any) {
      captured.push({identity: input.semanticSections.find((x:any)=>x.kind==='IDENTITY'), persona: input.semanticSections.find((x:any)=>x.kind==='PERSONA'), recent: input.semanticSections.find((x:any)=>x.kind==='RECENT_CONVERSATION'), direct: input.prompt.sections.find((x:any)=>x.name==='DirectContext'), policy: input.canonicalContext?.policy});
      return {decision:{addressing:'DIRECTED_TO_YUVI', reply:{disposition:'SILENCE'}, proactive:label==='A'?{action:'SUPPRESS',scope:{kind:'UNTIL_EXPLICIT_RESUME'}}:{action:'KEEP'}},providerMetadata:{model:'offline-research'}};
    },
    async generateAfterCognition(){throw Error('Not used');}
  };
  const runtime = new RuntimeOrchestrator({eventBus:new InMemoryEventBus({development:false}), memory:memory as never, providers, promptBuilder:new PromptBuilder(), conversation, character:character as never, p8CorrectionStore:{async loadCorrections(input:any){lookups.push(input);return {status:'SUCCESS_WITH_NO_CORRECTIONS',corrections:[]};},loadCorrectionByReference:async()=>({status:'UNAVAILABLE'}),appendCorrection:async()=>({status:'UNAVAILABLE'})} as never});
  return {runtime,captured,lookups,conversation};
}
const turn = (r:ReturnType<typeof build>, personaId:string, content:string) => r.runtime.handleUserMessage({sessionId:'same-session',subjectUserId:'Chen',personaId,content},{readMemory:false,writeMemory:false});

async function probe() {
  const a=build('A'),b=build('B');
  await turn(a,'yuvi.production','ONLY_A_PRIVATE_MARKER');
  await turn(b,'alice.production','ONLY_B_MARKER');
  await turn(a,'yuvi.production','A follow-up');
  const shared=new InMemoryConversationRepository(),sa=build('A',shared);
  await turn(sa,'yuvi.production','SHARED_REPO_A_MARKER');
  const sb=build('B',shared);await turn(sb,'alice.production','B cold restore');
  const direct=sb.captured[0].direct?.content ?? '';
  const recent=sb.captured[0].recent?.summary ?? '';
  const contexts=await Promise.all(['A','B'].map(scope=>withProviderWorkContext({scope},async()=>{await new Promise(r=>setTimeout(r,scope==='A'?4:1));return currentProviderWorkContext()?.scope;})));
  const pureA=createP8Projection({address:{characterInstanceId:'alice.production',personaProfileId:'alice-definition'},authoredInvariants:[{key:'character.name',target:'identity',statement:'东方爱丽丝',provenance:{source:'authored',reference:'research/alice',revision:'1'}}]});
  const pureT=createP8Projection({address:{characterInstanceId:'alice.testing',personaProfileId:'alice-definition'},authoredInvariants:[{key:'character.name',target:'identity',statement:'东方爱丽丝',provenance:{source:'authored',reference:'research/alice',revision:'1'}}]});
  const result={head:'94e20d0ceb63b127781ed66f60337ac655820001', boundary:'Actual Core and immutable P8; stub Character captures context and returns SILENCE, with no model/Journal/effect dispatch', a:{identity:a.captured[0].identity,p8Address:a.lookups[0].address,state:a.runtime.getProactiveState(),directAfterFollowup:a.captured[1].direct}, b:{identity:b.captured[0].identity,p8Address:b.lookups[0].address,state:b.runtime.getProactiveState()},sharedRepository:{rawDirectContainsOtherCharacter:direct.includes('SHARED_REPO_A_MARKER'),canonicalRecentContainsOtherCharacter:recent.includes('SHARED_REPO_A_MARKER'),rawDirect:direct,recent},asyncLocalContexts:contexts,pureP8Instances:[pureA.address,pureT.address]};
  await Promise.all([a,b,sa,sb].map(x=>x.runtime.sealAndDrainMemoryWrites()));
  writeFileSync('/workspace/research/multi-character/runtime-probe-result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}

function benchmark(n:number) {
  global.gc?.();const before=process.memoryUsage(),start=performance.now();
  const runtimes=Array.from({length:n},()=>new RuntimeOrchestrator({eventBus:new InMemoryEventBus({development:false}),memory:memory as never,promptBuilder:new PromptBuilder(),providers}));
  const constructionMs=performance.now()-start;global.gc?.();
  const after=process.memoryUsage();
  console.log(JSON.stringify({mode:'runtime-construction',n,constructionMs,before,after,heapDelta:after.heapUsed-before.heapUsed,rssDelta:after.rss-before.rss,retained:runtimes.length}));
}

const mode=process.argv[2]??'probe';
if(mode==='probe')await probe();else benchmark(Number(mode));
