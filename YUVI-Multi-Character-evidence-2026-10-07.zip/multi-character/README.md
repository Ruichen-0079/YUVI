# 本轮研究证据与复现

主报告：`../YUVI-Multi-Character-research-2026-10-07.md`。版本：`source-snapshot.json`。

这里存放研究脚本与实际结果。YUVI 源码未修改；没有生产 QQ 或真实用户数据。所有私密 marker 都是合成字符串。

## 已执行的检查

- Node v24.19.0 / pnpm 11.19.0。
- `pnpm install --ignore-scripts --frozen-lockfile --filter @companion/server...`。
- `pnpm exec tsc -b apps/server/tsconfig.json --pretty false`：exit 0，见 build-result.json。
- 现有相关 Vitest：142 passed、2 skipped，10 files。两个 skips 因未设置 YUVI_EFFECT_TEST_DATABASE_URL；不是 durable multi-instance acceptance。
- runtime-probe：真实 Core/P8，stub Character 返回 SILENCE，禁用 Memory read/write；复现固定 Yuvi Identity 和共享 repository cold-restore 串线。
- resource benchmark：compiled module graph、offline mocks / in-memory stores，没有生产模型/PG/可生产 Character。
- shared-provider-probe：真实 non-mock local HTTP adapter，两个 Registry、同一 llama.cpp/Qwen 服务；observer accounting passthrough 取代 A9。五次合成请求和 mutable accounting 覆盖。

完整 durable-gate 未运行，前置 PG16/pgvector、packaged PostgreSQL、Mem0 Python 未部署。不要从这些脚本推导完整多实例产品已被实现。

## 文件

| 文件 | 用途 |
| --- | --- |
| runtime-probe.ts / result.json | 未修改 Core 的隔离反例 |
| runtime-probe-compiled.ts / .mjs | 同逻辑，改用已经构建的 dist imports |
| appcontext-bench.ts / compiled.ts / compiled.mjs | 实际 AppContext 构造脚本 |
| resource-benchmark.json | 三次 fresh-process trials、一次双场景 PSS snapshot |
| resource-runner.py | 重跑同样数量的 trials/PSS 方法；新结果写 resource-benchmark-rerun.json |
| shared-provider-probe.ts / result.json | 单 serving endpoint 的实际请求和 accounting owner 记录 |
| shared-model-server.log / memory.json | 一个实际模型进程、slot、PSS/RSS |
| existing-tests.log / build-result.json | 检查的输出与 exit status |
| report-link-check.json | 本仓固定 SHA 的文件/行号与现有本地证据路径检查 |
| external/* | 读过的外部文件及固定版本 metadata；不包含完整 Git trees/clone |
| source-snapshot.json | HEAD、remote refs、核验时间与限制 |

代码原始执行目录为 `/workspace/research`，其中源码 checkout 名为 `YUVI-multi-character`，脚本目录名为 `multi-character`。TS probe 的结果输出路径保留原始绝对目录；若在别处复现，要先改该输出路径。compiled scripts 不 bundle YUVI，必须先构建对应 pinned source。

## 固定源码并复现

在 `/workspace/research` 下，若没有该源码目录：

```bash
git clone https://github.com/Ruichen-0079/YUVI.git YUVI-multi-character
git -C YUVI-multi-character checkout --detach 94e20d0ceb63b127781ed66f60337ac655820001
cd YUVI-multi-character
pnpm install --ignore-scripts --frozen-lockfile --filter @companion/server...
pnpm exec tsc -b apps/server/tsconfig.json --pretty false
pnpm exec tsx --conditions=development ../multi-character/runtime-probe.ts probe
python ../multi-character/resource-runner.py
```

现有测试的原命令：

```bash
pnpm exec vitest run packages/p8/src/index.test.ts packages/p8/src/persistence.test.ts packages/p8/src/voice-identity.test.ts packages/core/src/runtime-p8-correction.test.ts packages/core/src/runtime-proactive-scheduler.test.ts packages/core/src/runtime-cognition-interaction.test.ts packages/providers/src/context-exposure.test.ts packages/providers/src/registry.test.ts apps/server/src/character-production-path.test.ts apps/server/src/plugin-lifecycle.test.ts --maxWorkers=2 --minWorkers=1
```

模型 serving 实验独立于 Runtime/Memory durability。原实验使用现有 b11457 binary（commit 5ad1c5da0）、Qwen3-4B Q4_K_M 权重（2497281312 bytes），不在本包分发。可使用相同构建启动：

```bash
/workspace/research/model-experiment/llama-b11457/llama-server -m /workspace/research/model-experiment/qwen3-4b-q4_k_m.gguf --host 127.0.0.1 --port 8101 -c 2048 -t 3 -np 1 --reasoning off
```

等 localhost health 可用后，在源码目录：

```bash
pnpm exec tsx ../multi-character/shared-provider-probe.ts
```

不需要任何 QQ account；不要接生产 adapter。实验后停止这个模型进程。最新 llama.cpp router 文档来自另一个明确 SHA；本轮没有用 b11457 证明最新 router 的模型卸载行为。

## 历史 consumer 附录

报告引用之前 QQ 报告、旧插件本体和旧证据包。它们仍位于原研究目录，不重复并入本轮 archive。独立解压时，可将已有 QQ-Alice-research-2026-10-07.md、QQ-research-evidence-2026-10-07.zip 与 historical/plugin-readable.js 放在同级；本轮 source snapshot 保存原 ZIP SHA-256。

历史 ZIP 不能替代缺失 Host，也不约束通用 Definition/Instance 设计。
