"""Rerun the construction/PSS methodology. No models/PG/QQ involved.

Run after building pinned YUVI references. Uses compiled .mjs files next to this
script and writes a separate result; the originally recorded JSON is preserved.
"""
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path(__file__).resolve().parent
expected_head = "94e20d0ceb63b127781ed66f60337ac655820001"
source = root.parent / "YUVI-multi-character"
actual_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
if actual_head != expected_head:
    raise RuntimeError(f"Build the pinned source first: expected {expected_head}, got {actual_head}")
def command(kind, n, hold=0):
    script = root / ("runtime-probe-compiled.mjs" if kind == "runtime-construction" else "appcontext-bench-compiled.mjs")
    args = ["node", "--expose-gc", str(script), str(n)]
    if kind == "AppContext-construction" and hold:
        args.append(str(hold))
    return args

def fresh_trial(kind, n, trial):
    start = time.perf_counter()
    r = subprocess.run(command(kind, n), capture_output=True, text=True, check=True, cwd=root)
    row = json.loads(next(x for x in r.stdout.splitlines() if x.startswith('{"mode":')))
    row["wallIncludingLoadAndCloseMs"] = (time.perf_counter() - start) * 1000
    row["trial"] = trial
    return row

def smaps(pid):
    result = {}
    for line in Path(f"/proc/{pid}/smaps_rollup").read_text().splitlines():
        parts = line.split()
        if parts and parts[0].rstrip(":") in {"Rss","Pss","Private_Clean","Private_Dirty"}:
            result[parts[0].rstrip(":")] = int(parts[1]) * 1024
    return result

def held(counts):
    processes, contexts = [], []
    try:
        for n in counts:
            p = subprocess.Popen(command("AppContext-construction", n, 3000), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=root)
            processes.append(p)
        for p in processes:
            assert p.stdout is not None
            while True:
                line = p.stdout.readline()
                if not line:
                    raise RuntimeError(f"Benchmark exited before readiness: {p.stderr.read()}")
                if line.startswith('{"mode":'):
                    contexts.append(json.loads(line))
                    break
        memory = [smaps(p.pid) for p in processes]
        for p in processes:
            _, error = p.communicate(timeout=15)
            if p.returncode:
                raise RuntimeError(error)
        return {"memory":memory,"contexts":contexts}
    finally:
        for p in processes:
            if p.poll() is None:
                p.kill()
                p.communicate()

result = {
    "node": subprocess.check_output(["node","--version"], text=True).strip(),
    "head": actual_head,
    "trials": [
        fresh_trial(kind,n,trial)
        for kind,counts in [
            ("runtime-construction",[0,1,2,1000]),
            ("AppContext-construction",[0,1,2])
        ]
        for n in counts for trial in range(3)
    ],
    "limitation": "Construction-only, offline mocks/in-memory persistence; excludes production readiness, durable PG and model serving."
}
if os.name == "posix" and Path("/proc/self/smaps_rollup").exists():
    result["two_in_one_process"] = held([2])
    result["one_each_in_two_processes"] = held([1,1])
output = root / "resource-benchmark-rerun.json"
output.write_text(json.dumps(result,indent=2)+"\n")
for kind in ["runtime-construction","AppContext-construction"]:
    for n in sorted({r["n"] for r in result["trials"] if r["mode"]==kind}):
        rows=[r for r in result["trials"] if r["mode"]==kind and r["n"]==n]
        print(kind,n,round(statistics.median(r["after"]["rss"] for r in rows)/2**20,2),"RSS MiB")
print(output)
