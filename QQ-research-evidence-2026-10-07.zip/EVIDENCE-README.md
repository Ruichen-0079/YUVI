# QQ / YUVI 研究材料

研究日期 2026-10-07 UTC。完整判断见 `QQ-Alice-research-2026-10-07.md`。

本包包含实际取得的历史 QQ ZIP、抽出的插件本体、固定源码版本、公开 MaiBot issue/讨论快照、原源码门控复现及 56 次本地模型请求/输出。模型消息是合成样例，没有真实 QQ 消息或账号凭据。未包含模型权重、推理二进制或完整仓库。

`historical/plugin-readable.js` 从发布的 bundle 中提取，单独不能运行；原产物在 `qq-snowluma.zip`。当时 Host 的两个构建提交不能从公开远端取得，不能用这个包宣称完整恢复历史系统。

MaiBot 门控复现使用原始文件，附有上游 LICENSE 和固定 SHA。解压后在材料目录运行：

```sh
python maibot-offline-probe.py
```

模型实验需要自行取得 `model-experiment/methodology.json` 所列固定版本的 Qwen3 GGUF 和 llama.cpp。先启动本地 server；以下 `$MODEL_PATH` 指向要测的权重，推理二进制路径按实际解压目录调整：

```sh
./llama-server -m "$MODEL_PATH" --host 127.0.0.1 --port 8099 -c 2048 -t 3 -tb 3 --parallel 1 --jinja --reasoning off
python model-experiment/experiment.py qwen3-4b
```

8B 使用对应权重，并把实验输出名改为 `qwen3-8b`。脚本会覆盖同名结果文件，复测时请先另存原结果。提示、合成样例、请求参数都在脚本与 JSONL 中。原始 CPU wall latency 不能代表其他硬件。

研究标签只表示应否交主 Character 考虑的预期，不是生产东方爱丽丝的 RESPOND/SILENCE ground truth。不要把这 6 个正样例零遗漏解读为低真实漏放率。
