"""Execute upstream likelihood and dynamic gate without starting MaiBot."""
import importlib.util, pathlib, sys, json
ROOT=pathlib.Path(__file__).parent

def load(name,filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/'MaiBot/src/maisaka/turn_trigger'/filename)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod

rl=load('reply_likelihood_probe','reply_likelihood.py')
dg=load('dynamic_gate_probe','dynamic_gate.py')
results=[]
for recent in [10,40,60,80,120,200,300]:
    x=rl.ReplyLikelihoodInput(mention_bot=False,at_other=False,has_question_mark=True,
        placeholder_only=False,recent_self_ratio=0,recent_message_count=recent,
        seconds_since_bot_message=3600,pending_count=30)
    p=rl.estimate_reply_probability(x);gate=dg.DynamicReplyGate();gate.record_proactive_demand(.02,10000)
    decision=gate.evaluate(p,.8,10000)
    results.append({'recent_messages':recent,'probability':p,'threshold':decision.threshold,'passes':decision.should_trigger})
result={'upstream_head':'3f65e6fa8b8404e0c21be5779d1cd1e6a6d5eac7','probe':results,
        'limitation':'Reproduces the early gate condition only, not an entire chat or terminal reply decision.'}
(ROOT/'maibot-offline-probe.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
