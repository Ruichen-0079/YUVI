// plugins/qq-snowluma/index.js
import { randomUUID } from "node:crypto";
var promptPatches = [
  {
    fragment: "PERSONA",
    mode: "replace",
    content: "You are QQBot, a distinct QQ character with your own social memory. Express yourself naturally in an instant-messaging setting."
  },
  {
    fragment: "RESPONSE_REQUIREMENTS",
    content: "Prefer concise, natural QQ replies. Avoid unnecessary headings, tables and formal report structure. Use normal chat phrasing rather than customer-service style. In groups, not every message needs a response."
  }
];
var numericId = (value) => typeof value === "number" && Number.isSafeInteger(value) || typeof value === "string" && /^-?[0-9]{1,20}$/.test(value) ? String(value) : void 0;
function normalizeQQIdentity(sender, groupId, source = "inbound-sender", observedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  if (!sender || typeof sender !== "object" || Array.isArray(sender)) return { source, observedAt };
  const observation = { source, observedAt };
  const uin = numericId(sender.user_id);
  if (uin && /^[1-9][0-9]*$/.test(uin)) observation.qqUin = uin;
  for (const [wire, name] of [
    ["nickname", "nickname"],
    ["card", "groupCard"],
    ["remark", "friendRemark"],
    ["sex", "sex"],
    ["area", "area"],
    ["level", "level"],
    ["role", "role"],
    ["title", "title"]
  ]) {
    if (typeof sender[wire] === "string" || wire === "level" && typeof sender[wire] === "number")
      observation[name] = String(sender[wire]).slice(0, 256);
  }
  if (Number.isInteger(sender.age) && sender.age >= 0 && sender.age <= 150)
    observation.age = sender.age;
  if (groupId) observation.groupId = groupId;
  return observation;
}
function load() {
  let surface, socket, reconnect, stopped = false, ready = false, initialReady = false, inbound = 0;
  const pending = /* @__PURE__ */ new Map();
  const enrichments = /* @__PURE__ */ new Map();
  const recentMessages = /* @__PURE__ */ new Map();
  function rejectPending() {
    for (const slot of pending.values()) slot.reject(Error("OneBot response unavailable."));
    pending.clear();
  }
  function action(name, params, signal, timeoutMs = 15e3) {
    if (!socket || socket.readyState !== wrapper_default.OPEN || pending.size >= 32)
      return Promise.reject(Error("OneBot connection unavailable."));
    signal?.throwIfAborted();
    const current = socket, echo = randomUUID();
    return new Promise((resolve, reject) => {
      const finish = (error, value) => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
        pending.delete(echo);
        error ? reject(error) : resolve(value);
      };
      const abort = () => finish(Error("OneBot response lost or canceled."));
      const timer = setTimeout(abort, timeoutMs);
      pending.set(echo, {
        resolve: (value) => finish(null, value),
        reject: (error) => finish(error)
      });
      signal?.addEventListener("abort", abort, { once: true });
      try {
        current.send(JSON.stringify({ action: name, params, echo }));
      } catch {
        finish(Error("OneBot dispatch uncertain."));
      }
    });
  }
  async function connect(signal) {
    const current = new wrapper_default(surface.configuration.endpoint, {
      headers: { Authorization: `Bearer ${surface.configuration.accessToken}` },
      maxPayload: 65536,
      handshakeTimeout: 3e3
    });
    socket = current;
    ready = false;
    current.on("error", () => {
    });
    current.on("close", () => {
      if (socket !== current) return;
      ready = false;
      rejectPending();
      if (!stopped && initialReady)
        reconnect = setTimeout(() => {
          connect().catch(() => {
          });
        }, 1e3);
    });
    await new Promise((resolve, reject) => {
      const abort = () => {
        current.terminate();
        reject(Error("OneBot connection canceled."));
      };
      const cleanup = () => signal?.removeEventListener("abort", abort);
      signal?.addEventListener("abort", abort, { once: true });
      current.once("open", () => {
        cleanup();
        resolve();
      });
      current.once("error", () => {
        cleanup();
        reject(Error("Authenticated OneBot connection failed."));
      });
      current.once("close", () => {
        cleanup();
        reject(Error("OneBot connection closed."));
      });
    });
    current.on("message", (bytes) => {
      if (socket !== current || stopped) return;
      let event;
      try {
        event = JSON.parse(bytes.toString());
      } catch {
        return;
      }
      if (!event || typeof event !== "object" || Array.isArray(event)) return;
      const slot = pending.get(event.echo);
      if (slot) {
        if (event.status === "ok" && event.retcode === 0) slot.resolve(event.data);
        else
          slot.reject(Error("OneBot action response is non-authoritative for remote application."));
        return;
      }
      if (!ready || event.post_type !== "message" || numericId(event.self_id) !== surface.configuration.expectedAccount || inbound >= 16)
        return;
      const senderId = numericId(event.user_id) ?? numericId(event.sender?.user_id), kind = event.message_type === "private" ? "PRIVATE" : event.message_type === "group" ? "GROUP" : void 0;
      const conversationId = kind === "PRIVATE" ? senderId : numericId(event.group_id);
      if (!kind || !conversationId || !Array.isArray(event.message)) return;
      const content = event.message.filter((segment) => segment?.type === "text" && typeof segment.data?.text === "string").map((segment) => segment.data.text).join("").trim();
      if (!content || content.length > 4096) return;
      const reply = event.message.find((segment) => segment?.type === "reply");
      const observedAt = (/* @__PURE__ */ new Date()).toISOString(), groupId = kind === "GROUP" ? conversationId : void 0;
      const observation = normalizeQQIdentity(
        {
          ...event.sender,
          ...!numericId(event.sender?.user_id) && senderId ? { user_id: senderId } : {}
        },
        groupId,
        "inbound-sender",
        observedAt
      );
      const mentions = [
        ...new Set(
          event.message.filter((s) => s?.type === "at").map((s) => numericId(s.data?.qq)).filter((u) => u && /^[1-9][0-9]*$/.test(u))
        )
      ].slice(0, 4);
      const replyId = numericId(reply?.data?.id);
      const conversationKey = `${kind}:${conversationId}`;
      const replySenderId = replyId ? recentMessages.get(`${conversationKey}:${replyId}`) : void 0;
      const normalized = {
        accountId: surface.configuration.expectedAccount,
        conversationKind: kind,
        conversationId,
        senderId,
        content,
        identityObservations: [observation],
        mentionedIds: mentions,
        ...replySenderId ? { replySenderId } : {},
        ...Number.isFinite(event.time) && event.time > 0 && event.time < 864e10 ? { sourceTimestamp: new Date(event.time * 1e3).toISOString() } : {},
        ...numericId(event.message_id) ? { messageId: numericId(event.message_id) } : {},
        ...replyId ? { replyTo: replyId } : {}
      };
      if (senderId && normalized.messageId)
        recentMessages.set(`${conversationKey}:${normalized.messageId}`, senderId);
      if (recentMessages.size > 128) recentMessages.delete(recentMessages.keys().next().value);
      const enrichKey = `${conversationKey}:${senderId}`;
      if (senderId && (enrichments.get(enrichKey) ?? 0) < Date.now() - 36e5) {
        enrichments.set(enrichKey, Date.now());
        if (enrichments.size > 256) enrichments.delete(enrichments.keys().next().value);
        const name = groupId ? "get_group_member_info" : "get_stranger_info";
        action(
          name,
          { user_id: senderId, ...groupId ? { group_id: groupId, no_cache: false } : {} },
          void 0,
          1500
        ).then(
          (data) => surface?.receive({
            ...normalized,
            observationOnly: true,
            identityObservations: [
              normalizeQQIdentity({ ...data, user_id: data?.user_id ?? senderId }, groupId, name)
            ]
          })
        ).catch(() => {
        });
      }
      inbound++;
      Promise.resolve().then(() => surface.receive(normalized)).catch(() => {
      }).finally(() => inbound--);
    });
    try {
      const version = await action("get_version_info", {}, signal, 1500);
      if (version?.app_name !== "SnowLuma" || !["1.14.19", "1.14.19-node"].includes(version?.app_version) || version?.protocol_version !== "v11")
        throw Error("Unsupported SnowLuma protocol deployment; revalidate the transport contract.");
      const login = await action("get_login_info", {}, signal, 1500);
      const status = await action("get_status", {}, signal, 1500);
      if (stopped || socket !== current || current.readyState !== wrapper_default.OPEN || numericId(login?.user_id) !== surface.configuration.expectedAccount || status?.online !== true || status?.good !== true)
        throw Error("Expected QQ account is not ready.");
      ready = true;
      initialReady = true;
    } catch (error) {
      current.terminate();
      throw error;
    }
  }
  return {
    async start(context) {
      context.promptPatchRegistrations?.find((handle) => handle.surface === "qq")?.register(() => promptPatches);
      surface = context.surfaceRegistrations?.find((handle) => handle.surface === "qq");
      if (!surface) return;
      surface.register(async (message, signal) => {
        if (!ready || stopped) throw Error("Authenticated expected-account readiness unavailable.");
        const data = await action(
          message.conversationKind === "GROUP" ? "send_group_msg" : "send_private_msg",
          {
            [message.conversationKind === "GROUP" ? "group_id" : "user_id"]: message.conversationId,
            message: [{ type: "text", data: { text: message.content } }]
          },
          signal
        );
        const messageId = numericId(data?.message_id);
        if (!messageId) throw Error("OneBot send ACK missing local message handle.");
        return { acknowledged: true, messageId };
      });
      await connect(context.signal);
    },
    stop() {
      stopped = true;
      ready = false;
      clearTimeout(reconnect);
      rejectPending();
      socket?.terminate();
    },
    dispose() {
      stopped = true;
      ready = false;
      clearTimeout(reconnect);
      rejectPending();
      socket?.terminate();
      surface = void 0;
    }
  };
}
export {
  load,
  normalizeQQIdentity
};
