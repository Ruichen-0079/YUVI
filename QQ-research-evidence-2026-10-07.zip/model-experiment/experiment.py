"""Small adversarial router probe; synthetic labels are research expectations,
not production Character counterfactuals. No external model API or QQ traffic.
"""
import json, pathlib, time, urllib.request, statistics, sys

ROOT = pathlib.Path(__file__).parent
PROMPTS = [
    '你是群聊注意力路由器，不是群友或人格。主Character是东方爱丽丝。只判断最新消息是否值得让她考虑发言，最终她可以保持沉默。召回优先：隐式邀请、她参与过的话题的追问、可能相关但不确定的机会都放行。明确别人之间且与她无关、已经结束或过期的机会可不放行。不要生成回复，不因沉默时间长而放行。只输出JSON {"consider":true} 或 {"consider":false}。',
    '请为东方爱丽丝筛选值得交给主Character审视的群聊机会。你没有她的人格或Memory权限，也不决定她最终说话。目标是高召回：可能相关或拿不准应交给她，尤其隐式寻址和既有参与的延续；能确定无关、结束、过期才拦下。不把久未发言当理由。判断最新消息，只返回JSON，consider为布尔值，不写回复。'
]

# id, likely router opportunity, recent speaker-preserving messages
CASES = [
 ('implicit_invitation', True, 'A：这个报错怎么回事？\nB：感觉是昨天那个bug。\nC：爱丽丝昨天不是研究过吗？'),
 ('participation_followup', True, '爱丽丝：你试试把缓存清掉。\nA：还是一样。\nB：我这边正常。\nA：[reply=爱丽丝刚才的建议] 那还有啥招？'),
 ('different_addressee', False, 'A：@B 你昨天修的bug能讲一下吗？\nB：我等会儿发。\nC：好，等B。'),
 ('quoted_mention', False, 'A：日志里有一句“@爱丽丝 救一下”，只是转发的旧聊天。\nB：两年前的梗了。\nA：是，早解决了。'),
 ('interleaved_quote', True, '爱丽丝[m1]：把代理关掉试试。\nA[m2]：今晚吃啥？\nB[m3]：面。\nC[m4 reply=m1]：关了还是不行啊。'),
 ('slang_callback', True, '爱丽丝：这个更新我测过，会闪退。\nA：新版本又寄了。\nB：人偶师昨日预言成真，咋救啊'),
 ('opportunity_closed', False, 'A：爱丽丝知道这个bug怎么修吗？\nB：修好了，删缓存就行。\nA：好了，谢谢，别查了。'),
 ('ambient_joke', False, 'A：@B 你这代码写得像面条。\nB：你昨天还吃我面条来着。\nA：哈哈哈哈'),
 ('ack_turn', True, '爱丽丝：我查完了，周五截止。\nA：好，多谢爱丽丝！'),
 ('named_other_person', False, 'A：隔壁群有个真人也叫爱丽丝。\nB：她今天退课了。\nA：嗯，说的是那个人，不是这里的bot。'),
 ('unfinished_request', True, 'A：爱丽丝帮我看看\nA：刚才那个报错\nA：能不能保住存档？'),
 ('expired', False, '背景：以下消息已过去五分钟，其后话题结束，爱丽丝未参与；当前没有新消息。\nA：有谁知道这个报错？\nB：解决了，收工。')
]

def render(case, layout):
    ident, expected, raw = case
    base = '当前audience=群聊G；当前时机=最新消息刚到，除非背景另有说明；身份仅为显示名，未绑定现实Person。\n'
    if layout == 'raw': return base + raw
    # This is a layout-only probe; the same text is retained, not a lossy summary.
    return base + json.dumps({'conversation':'G', 'recent_messages_verbatim':raw.split('\n'), 'latest_message':raw.split('\n')[-1]}, ensure_ascii=False)

def call_model(prompt, content):
    body = {'messages':[{'role':'system','content':prompt},{'role':'user','content':content}],
            'temperature':0, 'seed':42, 'max_tokens':32,
            'chat_template_kwargs':{'enable_thinking':False},
            'response_format':{'type':'json_object'}}
    request = urllib.request.Request('http://127.0.0.1:8099/v1/chat/completions',
        data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    started = time.monotonic()
    with urllib.request.urlopen(request,timeout=300) as response: result=json.load(response)
    return result, time.monotonic()-started, body

def main(model):
    out=ROOT/(model+'-results.jsonl')
    jobs=[(case, p, 'raw') for p in range(2) for case in CASES]
    jobs += [(CASES[i],0,'json') for i in [0,4,5,6]]
    with out.open('w') as f:
        for case,p,layout in jobs:
            response,seconds,request=call_model(PROMPTS[p],render(case,layout))
            text=response['choices'][0]['message'].get('content','')
            try: decision=json.loads(text).get('consider')
            except Exception: decision=None
            record={'model':model,'case':case[0],'research_expected':case[1],
                'prompt':p,'layout':layout,'decision':decision,'seconds':seconds,
                'request':request,'response':response}
            f.write(json.dumps(record,ensure_ascii=False)+'\n');f.flush()
            print(model,case[0],p,layout,decision,round(seconds,2),flush=True)

if __name__=='__main__': main(sys.argv[1])
